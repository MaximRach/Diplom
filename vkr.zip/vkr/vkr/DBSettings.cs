﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace vkr
{
    public partial class DBSettings : Form
    {
        Settings.DbSettings dbsettings = new Settings.DbSettings();
        public DBSettings()
        {
            InitializeComponent();
            FillSettings();
        }
        private void FillSettings()
        {
            List<string> Settings=dbsettings.getSettings();
            if (Settings.Count == 4) {
                textBoxDBSHost.Text = Settings[0];
                textBoxDBSUserName.Text = Settings[1];
                textBoxDBSPassword.Text = Settings[2];
                textBoxDBSDBName.Text = Settings[3];
            }
        }
        private void buttonDBSUpdate_Click(object sender, EventArgs e)
        {
            dbsettings.Edit(textBoxDBSHost.Text,textBoxDBSUserName.Text,textBoxDBSPassword.Text,textBoxDBSDBName.Text);
        }
    }
}
