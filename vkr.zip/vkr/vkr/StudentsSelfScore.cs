﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace vkr
{
    class StudentsSelfScore
    {
        Settings.DbSettings dbsettings = new Settings.DbSettings();
        List<StudentTS> Team = new List<StudentTS>();
        private DataTable GetStudentTable()
        {
            string connString = dbsettings.GetConnString();
            NpgsqlConnection nc = new NpgsqlConnection(connString);
            nc.Open();
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = nc;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "SELECT \"studentId\",\"lastName\",\"middleName\", \"fistName\" FROM \"Student\" ;";
            NpgsqlDataReader dr = comm.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            comm.Dispose();
            nc.Close();
            return dt;
        }
        public void GetData(DataTable dt)
        {
            List<int> tempId = new List<int>();
            for (int i=0; i < dt.Rows.Count; i++)
            {
                if (!tempId.Contains(Convert.ToInt32(dt.Rows[i]["studAnalyzedId"]))){
                    tempId.Add(Convert.ToInt32(dt.Rows[i]["studAnalyzedId"]));
                }
            }
            DataTable StudentTable = GetStudentTable();
            for (int i = 0; i < tempId.Count; i++)
            {
                StudentTS tempStudent = new StudentTS(tempId[i]);
                tempStudent.name = GetNameById(tempId[i], StudentTable);
                Team.Add(tempStudent);
            }
        }
        private string GetNameById(int id,DataTable dt)
        {
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (Convert.ToInt32(dt.Rows[i]["studentId"]) == id)
                {
                    return dt.Rows[i]["lastName"].ToString() + " " + dt.Rows[i]["fistName"].ToString()[0] + " "
                    + dt.Rows[i]["middleName"].ToString()[0];
                }
            }
            return "";
        }
        public DataTable TableMean(DataTable dt)
        {
            for (int i = 0; i < Team.Count; i++)
            {
                for (int j = 0; j < dt.Rows.Count; j++)
                {
                    if (Convert.ToInt32(dt.Rows[j]["studAnalyzedId"]) == Team[i].id)
                    {
                        Team[i].score += Convert.ToDouble(dt.Rows[j]["scoreTeammate"]);
                        Team[i].count += 1;
                    }
                }
            }
            DataTable rezult=new DataTable();
            rezult.Columns.Add("Student");
            rezult.Columns.Add("MeanScore");
            for (int i = 0; i < Team.Count; i++)
            {
                rezult.Rows.Add(Team[i].name, Team[i].AMean());
            }
            return rezult;
        }
        public DataTable SelfScoreTable(DataTable dt)
        {
            DataTable rezult = new DataTable();
            rezult.Columns.Add("Оценщик");
            rezult.Columns.Add("Оцениваемый");
            rezult.Columns.Add("Оценка");
            DataTable StudentTable = GetStudentTable();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                rezult.Rows.Add(GetNameById(Convert.ToInt32(dt.Rows[i]["studAssessingId"]),StudentTable),GetNameById(Convert.ToInt32(dt.Rows[i]["studAnalyzedId"]),StudentTable), dt.Rows[i]["scoreTeammate"]);
            }

            return rezult;
        }
    }
    class StudentTS
    {
        public int id;
        public string name;
        public double score = 0;
        public int count = 0;
        public StudentTS(int ID)
        {
            this.id = ID;
        }
        public string AMean()
        {
            if (count > 0)
            {
                return Convert.ToString(score / count);
            }
            else
            {
                return "---";
            }
        }
    }
}
