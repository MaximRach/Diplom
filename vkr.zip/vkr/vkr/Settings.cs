﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace vkr
{
    public class Settings
    {
        public class DbSettings
        {
            public string Host;
            public string Username;
            public string Pass;
            public string DatabaseName;
            private void SaveEdit()
            {
                string filename = Globals.DbSettingsFile;

                if (File.Exists(filename)) File.Delete(filename);

                using (FileStream fs = new FileStream(filename, FileMode.Create))
                {
                    XmlSerializer xser = new XmlSerializer(typeof(DbSettings));
                    xser.Serialize(fs, this);
                    fs.Close();
                }
            }

            public void Edit(string host, string username, string pass, string dbname)
            {
                this.Host = host;
                this.Username = username;
                this.Pass = pass;
                this.DatabaseName = dbname;
                SaveEdit();
            }
            public List<string> getSettings()
            {
                List<string> rezult = new List<string>();
                this.LoadSettings();
                rezult.Add(this.Host);
                rezult.Add(this.Username);
                rezult.Add(this.Pass);
                rezult.Add(this.DatabaseName);
                return rezult;
            }
            private void LoadSettings()
            {
                DbSettings settings = null;
                string filename = Globals.DbSettingsFile;
                if (File.Exists(filename))
                {
                    using (FileStream fs = new FileStream(filename, FileMode.Open))
                    {
                        XmlSerializer xser = new XmlSerializer(typeof(DbSettings));
                        settings=(DbSettings)xser.Deserialize(fs);
                        fs.Close();
                    }
                    this.Host = settings.Host;
                    this.Username = settings.Username;
                    this.Pass = settings.Pass;
                    this.DatabaseName = settings.DatabaseName;
                }
                else
                {
                    MessageBox.Show("Отсутствует файл настроек подключения к базе данных");
                }
            }
            public string GetConnString()
            {
                string rez = "";
                this.LoadSettings();
                rez = "Host=" + "\"" + this.Host + "\"" + "; Username=" + "\"" + this.Username + "\"" + ";Password=" + "\"" + this.Pass + "\"" + ";Database=" + "\"" + this.DatabaseName + "\"";
                return rez;
            }
        }
    }
}
