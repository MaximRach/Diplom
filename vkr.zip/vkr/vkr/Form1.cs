﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using ZedGraph;

namespace vkr
{
    public partial class MainForm : Form
    {
        Settings.DbSettings dbsettings = new Settings.DbSettings();
        
        public MainForm()
        {
            InitializeComponent();
            checkedListBox1.Items.Add("x^2");
            checkedListBox1.Items.Add("x");
            checkedListBox1.Items.Add("-2x");
        }
        private double fx2(double x)
        {
            return x * x;
        }
        private void drawfx2()
        {
            double xmin = -50;
            double xmax = 50;
            
            List<double> xa = new List<double> { };
            List<double> ya = new List<double> { };
            for (double x = xmin; x < xmax; x += 0.01)
            {
                xa.Add(x);
                ya.Add(fx2(x));
            }
            LineItem test = GL1.GraphPane.AddCurve("x^2", xa.ToArray(), ya.ToArray(), Color.Red, SymbolType.None);
            GL1.GraphPane.XAxis.Title.Text = "test";
            
            GL1.GraphPane.AxisChange();
            GL1.Invalidate();
        }
        private void drawx()
        {
            double xmin = -50;
            double xmax = 50;

            List<double> xa = new List<double> { };
            List<double> ya = new List<double> { };
            for (double x = xmin; x < xmax; x += 0.01)
            {
                xa.Add(x);
                ya.Add(x);
            }
            LineItem test = GL1.GraphPane.AddCurve("x", xa.ToArray(), ya.ToArray(), Color.LimeGreen, SymbolType.None);
            GL1.GraphPane.XAxis.Title.Text = "test";
            GL1.GraphPane.AxisChange();
            GL1.Invalidate();
        }
        private void drawm2x()
        {
            double xmin = -50;
            double xmax = 50;

            List<double> xa = new List<double> { };
            List<double> ya = new List<double> { };
            for (double x = xmin; x < xmax; x += 0.01)
            {
                xa.Add(x);
                ya.Add(-2*x);
            }
            LineItem test = GL1.GraphPane.AddCurve("-2x", xa.ToArray(), ya.ToArray(), Color.Blue, SymbolType.None);
            GL1.GraphPane.XAxis.Title.Text = "test";
            GL1.GraphPane.AxisChange();
            GL1.Invalidate();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            GL1.GraphPane.Title.Text = "Grafiicaaaa";
            GL1.GraphPane.CurveList.Clear();
            if (checkedListBox1.CheckedItems.Contains("x"))
            {
                drawx();
            }
            if (checkedListBox1.CheckedItems.Contains("x^2"))
            {
                drawfx2();
            }
            if (checkedListBox1.CheckedItems.Contains("-2x"))
            {
                drawm2x();
            }
        }

        private void WordsListEditorButton_Click(object sender, EventArgs e)
        {
            WordsListEditor WLE = new WordsListEditor();
            WLE.Show();
        }
        
        private string GetConnString()
        {
            string filename = "config/bd_config.xml";
            string rez = "";
            try
            {
                var bd_config_doc = new XmlDocument();
                bd_config_doc.Load(filename);
                var root = bd_config_doc.DocumentElement;
                List<string> atr = GetItemXml(root);
               /* foreach (var child in root.ChildNodes)
                {
                    //atr.Add(child.ToString());

                    if (child is XmlText text)
                    {
                        // Если зависимый элемент текст,
                        // то выводим его через тире.
                        atr.Add(text.InnerText);
                    }
                }*/
                //rez= ";Database=" + atr.po;
                rez = "Host=" + atr[0] + ";Username=" + atr[1] + ";Password=" + atr[2] + ";Database=" + atr[3];
                textBox1.Text = rez;
            }
            catch
            {
                textBox1.Text = "error";
            }
            return "0";
        }
        private List<string> GetItemXml(XmlElement root)
        {
            List<string> rez = new List<string>();
            foreach (var child in root.ChildNodes)
            {
                if (child is XmlElement node)
                {
                    // Если зависимый элемент тоже элемент,
                    // то переходим на новую строку 
                    // и рекурсивно вызываем метод.
                    // Следующий элемент будет смещен на один отступ вправо.
                    GetItemXml(node);
                }

                if (child is XmlText text)
                {
                    // Если зависимый элемент текст,
                    // то выводим его через тире.
                    rez.Add(text.InnerText);
                }
            }
            return rez;
        }
        private void button2_Click(object sender, EventArgs e)
        {
            string connString = "Host=localhost;Username=postgres;Password=4121;Database=testdb1";
            NpgsqlConnection nc = new NpgsqlConnection(connString);

                //Открываем соединение.
                nc.Open();
            
            // NpgsqlCommand npgc = new NpgsqlCommand("SELECT * FROM public.products", nc);
            //NpgsqlDataReader ndr = npgc.ExecuteReader();//Если запрос возвращает таблицу
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = nc;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "select * from products";
            NpgsqlDataReader dr = comm.ExecuteReader();
           // if (dr.HasRows)
            //{
                DataTable dt = new DataTable();
                dt.Load(dr);
                dataGridView1.DataSource = dt;
            //}
            comm.Dispose();
            nc.Close();
            //double test1 = double(dataGridView1.Rows[1].Cells[3].Value.ToString());
            double test2 = Convert.ToDouble(dt.Rows[1][3]);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //GetConnString();
            //dbsettings.Edit("localhost", "postgres", "4121", "testdb1");
            textBox1.Text=dbsettings.GetConnString();
            string connString = "Host=localhost;Username=postgres;Password=4121;Database=testdb1";
            if(textBox1.Text==connString) MessageBox.Show("Ave");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            /*WordCounter w1 = new WordCounter();
            WordCounter w2 = new WordCounter();
            WordCounter w3 = new WordCounter();
            w1.EditWord("test1", "qwe");
            w2.EditWord("test1", "qaz");
            w3.EditWord("test2", "wsx");
            WordsCounter testwsc = new WordsCounter();
            testwsc.AddWord(w1);
            testwsc.AddWord(w2);
            testwsc.AddWord(w3);
            string s = "qweqweqazwsxwsxrrr";
            testwsc.FindAndCount(s);
            textBox1.Text = (testwsc.ToString());
            dataGridView1.DataSource = testwsc.ToDataTable();*/
            string connString = dbsettings.GetConnString();
            NpgsqlConnection nc = new NpgsqlConnection(connString);
            nc.Open();
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = nc;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "SELECT \"Dictionary\".\"word\", \"Category\".\"name\" FROM \"Dictionary\" JOIN \"Category\" ON \"Dictionary\".\"categoryId\" = \"Category\".\"categoryId\";";
            NpgsqlDataReader dr = comm.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            dataGridView1.DataSource = dt;
            comm.Dispose();
            nc.Close();
        }

        private void polarg(WordCounter w1, WordCounter w2, WordCounter w3, WordCounter w4)
        {

            /*LineItem myCurve = GL1.GraphPane.AddCurve(a.Word, list, Color.Blue, SymbolType.Diamond);
            GL1.GraphPane.AxisChange();
            GL1.Invalidate();*/

            GL1.GraphPane.XAxis.MajorGrid.IsVisible = true;
            GL1.GraphPane.YAxis.MajorGrid.IsVisible = true;

            GL1.GraphPane.YAxis.MajorGrid.IsZeroLine = false;
            GL1.GraphPane.XAxis.Title.IsVisible = false;
            GL1.GraphPane.YAxis.Title.IsVisible = false;
            // Создаем список точек
            RadarPointList points = new RadarPointList();


            // Т.к. в списке будет 4 точки, то и окружность будет разбиваться на 4 части
            // Обход точек будет осуществляться против часовой стрелки
            points.Clockwise = false;

            // Первая точка - сверху над началом координат. Расстояние до центра = 1. Второй параметр в большинстве случаев не используется
            points.Add(w1.Count, 1);
            TextObj text1 = new TextObj(w1.Word, 0.2, w1.Count+0.2);

            // Вторая точка - слева от начала координат.  Расстояние до центра = 2
            points.Add(w2.Count, 1);
            TextObj text2 = new TextObj(w2.Word, -w2.Count+0.2, 0.2);
            // Третья точка - снизу под началом координат.  Расстояние до центра = 3
            points.Add(w3.Count, 1);
            TextObj text3 = new TextObj(w3.Word, 0.2, 0.2-w3.Count);
            // Четвертая точка - справа от начала координат.  Расстояние до центра = 4
            points.Add(w4.Count, 1);
            TextObj text4 = new TextObj(w4.Word, w4.Count + 0.2, 0.2);
            GL1.GraphPane.GraphObjList.Add(text1);
            GL1.GraphPane.GraphObjList.Add(text2);
            GL1.GraphPane.GraphObjList.Add(text3);
            GL1.GraphPane.GraphObjList.Add(text4);

            // Добавляем кривую по этим четырем точкам
            LineItem myCurve = GL1.GraphPane.AddCurve("", points, Color.Black, SymbolType.None);


            // Для наглядности нарисуем расстояния от начала координат до каждой из точек
            /*ArrowObj arrow1 = new ArrowObj(0, 0, 0, 1);
            GL1.GraphPane.GraphObjList.Add(arrow1);

            ArrowObj arrow2 = new ArrowObj(0, 0, -2, 0);
            GL1.GraphPane.GraphObjList.Add(arrow2);

            ArrowObj arrow3 = new ArrowObj(0, 0, 0, -3);
            GL1.GraphPane.GraphObjList.Add(arrow3);

            ArrowObj arrow4 = new ArrowObj(0, 0, 4, 0);
            GL1.GraphPane.GraphObjList.Add(arrow4);*/

            // Отметим начало координат черным квадратиком
            /*BoxObj box = new BoxObj(-0.05, 0.05, 0.1, 0.1, Color.Black, Color.Black);
            GL1.GraphPane.GraphObjList.Add(box);*/

            GL1.AxisChange();

            GL1.Invalidate();
        }
        private void polarplotbutton_Click(object sender, EventArgs e)
        {
            GL1.GraphPane.XAxis.Cross = 0.0;
            GL1.GraphPane.YAxis.Cross = 0.0;
            //WordsCounter testwsc = new WordsCounter();
            WordCounter w1 = new WordCounter(), w2 = new WordCounter(), w3 = new WordCounter(), w4 = new WordCounter(),w5 = new WordCounter();
            w1.EditWord("c1", "qwe",37);
            w2.EditWord("c1", "qaz",41);
            w3.EditWord("c2", "wsx",29);
            w4.EditWord("c2", "rt",52);
            polarg(w1, w2, w3, w4);
           /* w5.EditWord("c2", "uyu",2);
            /*
            testwsc.AddWord(w1);
            testwsc.AddWord(w2);
            testwsc.AddWord(w3);
            testwsc.AddWord(w4);
            testwsc.AddWord(w5);*/
            /*int a =5;
            double b = 360 / a;
            //
            GL1.GraphPane.XAxis.Scale.IsSkipFirstLabel = true;
            GL1.GraphPane.XAxis.Scale.IsSkipLastLabel = true;

            // Отключим отображение меток в точке пересечения с другой осью
            GL1.GraphPane.XAxis.Scale.IsSkipCrossLabel = true;


            // Отключим отображение первых и последних меток по осям
            GL1.GraphPane.YAxis.Scale.IsSkipFirstLabel = true;

            // Отключим отображение меток в точке пересечения с другой осью
            GL1.GraphPane.YAxis.Scale.IsSkipLastLabel = true;
            GL1.GraphPane.YAxis.Scale.IsSkipCrossLabel = true;

            // Спрячем заголовки осей
            GL1.GraphPane.XAxis.Title.IsVisible = false;
            GL1.GraphPane.YAxis.Title.IsVisible = false;
            //
            GL1.AxisChange();
            GL1.Invalidate();*/
        }

        private void gistgraf(string name, List<string> text, List<double> numbers)
        {
            GL1.GraphPane.CurveList.Clear();
            BarItem curve = GL1.GraphPane.AddBar(name, null, numbers.ToArray(), Color.Orange);
            // Настроим ось X так, чтобы она отображала текстовые данные
            GL1.GraphPane.XAxis.Type = AxisType.Text;

            // Уставим для оси наши подписи
            GL1.GraphPane.XAxis.Scale.TextLabels = text.ToArray();

            // Вызываем метод AxisChange (), чтобы обновить данные об осях.
            GL1.GraphPane.AxisChange();

            // Обновляем график
            GL1.Invalidate();
        }
        private void gistbutton_Click(object sender, EventArgs e)
        {
            List<string> text = new List<string> { "t1","t2","t3","t4"};
            List<double> numbers = new List<double> { 35, 51, 12,47 };
            gistgraf("testgist", text, numbers);
        }
    }
}
