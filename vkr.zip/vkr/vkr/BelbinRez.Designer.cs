﻿namespace vkr
{
    partial class BelbinRez
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.comboBoxBRGroup = new System.Windows.Forms.ComboBox();
            this.dataGridViewBR = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBR)).BeginInit();
            this.SuspendLayout();
            // 
            // comboBoxBRGroup
            // 
            this.comboBoxBRGroup.FormattingEnabled = true;
            this.comboBoxBRGroup.Location = new System.Drawing.Point(13, 13);
            this.comboBoxBRGroup.Name = "comboBoxBRGroup";
            this.comboBoxBRGroup.Size = new System.Drawing.Size(170, 28);
            this.comboBoxBRGroup.TabIndex = 0;
            this.comboBoxBRGroup.SelectedIndexChanged += new System.EventHandler(this.comboBoxBRGroup_SelectedIndexChanged);
            // 
            // dataGridViewBR
            // 
            this.dataGridViewBR.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewBR.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewBR.Location = new System.Drawing.Point(13, 48);
            this.dataGridViewBR.Name = "dataGridViewBR";
            this.dataGridViewBR.RowHeadersWidth = 51;
            this.dataGridViewBR.Size = new System.Drawing.Size(775, 390);
            this.dataGridViewBR.TabIndex = 1;
            this.dataGridViewBR.Text = "dataGridView1";
            // 
            // BelbinRez
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dataGridViewBR);
            this.Controls.Add(this.comboBoxBRGroup);
            this.Name = "BelbinRez";
            this.Text = "Результаты теста Белбина";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBR)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBoxBRGroup;
        private System.Windows.Forms.DataGridView dataGridViewBR;
    }
}