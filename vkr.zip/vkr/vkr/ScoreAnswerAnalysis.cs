﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace vkr
{

    class ScoreAnswerAnalysis
    {
        List<Question> QuestionList = new List<Question>();
        
        public void FindAndCount(DataTable dt)
        {
            Question temp = new Question("TestQuestion");
            QuestionList.Add(temp);
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                for (int j = 0; j < QuestionList.Count; j++)
                {
                    if (QuestionList[j].text == dt.Rows[i]["questionText"].ToString())
                    {
                        QuestionList[j].SumScore += Convert.ToDouble(dt.Rows[i]["scoreSurvey"]);
                        QuestionList[j].CountAnswer += 1;
                        break;
                    }
                    else
                    {
                        Question tempQuestion=new Question(dt.Rows[i]["questionText"].ToString());
                        QuestionList.Add(tempQuestion);
                        QuestionList[j].SumScore += Convert.ToDouble(dt.Rows[i]["scoreSurvey"]);
                        QuestionList[j].CountAnswer += 1;
                    }
                }
            }
        }
        public DataTable Find3Min()
        {
            double min1= int.MaxValue,min2 = int.MaxValue,min3 = int.MaxValue;
            string name1 = "", name2 = "", name3 = "";
            if (QuestionList.Count < 3)
            {
                MessageBox.Show("Неправильные данные");
                return new DataTable();
            }
            for (int i = 0; i < QuestionList.Count; i++)
            {
                if ((QuestionList[i].AMean() < min1) && (QuestionList[i].text != "TestQuestion") && (QuestionList[i].AMean() != 0))
                {
                    min1 = QuestionList[i].AMean();
                    name1 = QuestionList[i].text;
                }
            }
            for (int i = 0; i < QuestionList.Count; i++)
            {
                if ((QuestionList[i].AMean() < min2)&&(QuestionList[i].text!=name1) && (QuestionList[i].text != "TestQuestion") && (QuestionList[i].AMean() != 0))
                {
                    min2 = QuestionList[i].AMean();
                    name2 = QuestionList[i].text;
                }
            }
            for (int i = 0; i < QuestionList.Count; i++)
            {
                if ((QuestionList[i].AMean() < min3) && (QuestionList[i].text != name1) && (QuestionList[i].text != name2) && (QuestionList[i].text != "TestQuestion") && (QuestionList[i].AMean() != 0))
                {
                    min3 = QuestionList[i].AMean();
                    name3 = QuestionList[i].text;
                }
            }
            DataTable rezult = new DataTable();
            rezult.Columns.Add("Question");
            rezult.Columns.Add("MeanScore");
            rezult.Rows.Add(name1, Math.Round(min1,2));
            rezult.Rows.Add(name2, Math.Round(min2,2));
            rezult.Rows.Add(name3, Math.Round(min3,2));
            return rezult;
        }
        public DataTable Find3Max()
        {
            double max1 = int.MinValue, max2 = int.MinValue, max3 = int.MinValue;
            string name1 = "", name2 = "", name3 = "";
            if (QuestionList.Count < 3)
            {
                MessageBox.Show("Неправильные данные");
                return new DataTable();
            }
            for (int i = 0; i < QuestionList.Count; i++)
            {
                if ((QuestionList[i].AMean() > max1) && (QuestionList[i].text != "TestQuestion"))
                {
                    max1 = QuestionList[i].AMean();
                    name1 = QuestionList[i].text;
                }
            }
            for (int i = 0; i < QuestionList.Count; i++)
            {
                if ((QuestionList[i].AMean() > max2) && (QuestionList[i].text != name1) && (QuestionList[i].text != "TestQuestion"))
                {
                    max2 = QuestionList[i].AMean();
                    name2 = QuestionList[i].text;
                }
            }
            for (int i = 0; i < QuestionList.Count; i++)
            {
                if ((QuestionList[i].AMean() > max3) && (QuestionList[i].text != name1) && (QuestionList[i].text != name2) && (QuestionList[i].text != "TestQuestion"))
                {
                    max3 = QuestionList[i].AMean();
                    name3 = QuestionList[i].text;
                }
            }
            DataTable rezult = new DataTable();
            rezult.Columns.Add("Question");
            rezult.Columns.Add("MeanScore");
            rezult.Rows.Add(name1, Math.Round(max1,2));
            rezult.Rows.Add(name2, Math.Round(max2,2));
            rezult.Rows.Add(name3, Math.Round(max3,2));
            return rezult;
        }
    }
    class Question
    {
        public string text;
        public double SumScore=0;
        public double CountAnswer = 0;
        public Question(string t)
        {
            this.text = t;
        }
        public double AMean()
        {
            if (this.CountAnswer != 0)
            {
                return this.SumScore / this.CountAnswer;
            }
            else
            {
                return 0;
            }
        }
    }
    class Student
    {
        public int id;
        public double sumscore = 0;
        public int countanswer = 0;
        public Student(int ID)
        {
            this.id = ID;
        }
        public double AMean()
        {
            if (this.countanswer != 0)
            {
                return Math.Round(this.sumscore / this.countanswer,2);
            }
            else
            {
                return 0;
            }
        }
    }
    class ListSudent
    {
        Settings.DbSettings dbsettings = new Settings.DbSettings();
        List<Student> LS = new List<Student>();
        public void FindAndCount(DataTable dt)
        {
            /*Student temp = new Student(-1);
            LS.Add(temp);
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                for (int j = 0; j < LS.Count; j++)
                {
                    if (LS[j].id == Convert.ToInt32(dt.Rows[i]["studentId"]))
                    {
                        LS[j].sumscore += Convert.ToDouble(dt.Rows[i]["scoreSurvey"]);
                        LS[j].countanswer += 1;
                        break;
                    }
                    else
                    {
                        Student tempStudent = new Student(Convert.ToInt32(dt.Rows[i]["studentId"]));
                        LS.Add(tempStudent);
                        LS[j].sumscore += Convert.ToDouble(dt.Rows[i]["scoreSurvey"]);
                        LS[j].countanswer += 1;
                    }
                }
            }*/
            //Student temp = new Student(-1);
            //LS.Add(temp);
            /*for (int i = 0; i < dt.Rows.Count; i++)
            {
                for (int j=0; j < LS.Count; j++)
                {
                    if (LS[j].id == Convert.ToInt32(dt.Rows[i]["studentId"]))
                    {
                        break;
                    }
                    Student student = new Student(Convert.ToInt32(dt.Rows[i]["studentId"]));
                    LS.Add(student);
                }
            }*/
            List<int> ID = new List<int>();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                ID.Add(Convert.ToInt32(dt.Rows[i]["studentId"]));
            }
            List<int> UnicueId = new List<int>();
            for (int i = 0; i < ID.Count; i++)
            {
                if (!(UnicueId.Contains(ID[i])))
                {
                    UnicueId.Add(ID[i]);
                }
            }
            for (int i = 0; i < UnicueId.Count; i++) 
            {
                Student student = new Student(UnicueId[i]);
                LS.Add(student);
            }

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                for (int j = 0; j < LS.Count; j++)
                {
                    if (LS[j].id == Convert.ToInt32(dt.Rows[i]["studentId"]))
                    {
                        LS[j].sumscore += Convert.ToDouble(dt.Rows[i]["scoreSurvey"]);
                        LS[j].countanswer += 1;
                    }
                }
            }
            //LS.RemoveAt(0);
        }
        private bool CheckMeanInDT(DataTable dt, double mean)
        {
            for (int j = 0; j < dt.Rows.Count; j++)
            {
                if (Convert.ToDouble(dt.Rows[j]["MeanScore"]) == mean)
                {
                    return true;
                }
            }
            return false;
        }
        public DataTable GetDataForGraph()
        {
            string connString = dbsettings.GetConnString();
            NpgsqlConnection nc = new NpgsqlConnection(connString);
            nc.Open();
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = nc;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "SELECT \"studentId\" FROM \"TeamStudent\" ;";
            NpgsqlDataReader dr = comm.ExecuteReader();
            DataTable dts = new DataTable();
            dts.Load(dr);

            comm.Dispose();
            nc.Close();


            DataTable rezult = new DataTable();
            rezult.Columns.Add("MeanScore");
            rezult.Columns.Add("CountStudent");
            for (int i = 0; i < LS.Count; i++)
            {
                if((CheckMeanInDT(rezult, LS[i].AMean())) &&(LS[i].id!=-1) && (LS[i].AMean() != 0))
                {
                    for (int j = 0; j < rezult.Rows.Count; j++)
                    {
                        if ((Convert.ToDouble(rezult.Rows[j]["MeanScore"])== LS[i].AMean())&&(Convert.ToInt32(rezult.Rows[j]["CountStudent"])<=dts.Rows.Count))
                        {
                            rezult.Rows[j]["CountStudent"] =Convert.ToInt32( rezult.Rows[j]["CountStudent"])+1;
                            break;
                        }
                    }
                }
                else
                {
                    if ((LS[i].id != -1) && (LS[i].AMean() != 0))
                    {
                        rezult.Rows.Add(LS[i].AMean(), 1);
                    }
                }
            }
            return rezult;
        } 
    }
}
