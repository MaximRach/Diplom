﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace vkr
{
    public partial class StudentsScore : Form
    {
        Settings.DbSettings dbsettings = new Settings.DbSettings();
        public StudentsScore()
        {
            InitializeComponent();
            FillCBGroup();
        }

        private void FillCBGroup()
        {
            string connString = dbsettings.GetConnString();
            NpgsqlConnection nc = new NpgsqlConnection(connString);
            nc.Open();
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = nc;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "SELECT \"name\" FROM \"Group\" ;";
            NpgsqlDataReader dr = comm.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                comboBoxSSGroup.Items.Add(dt.Rows[i]["name"]);
            }
            comm.Dispose();
            nc.Close();
        }
        private void comboBoxSSGroup_SelectedIndexChanged(object sender, EventArgs e)
        {
            FillDataTableStudentScore();
        }
        private void FillDataTableStudentScore()
        {
            string connString = dbsettings.GetConnString();
            NpgsqlConnection nc = new NpgsqlConnection(connString);
            nc.Open();
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = nc;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "SELECT \"Student\".\"fistName\",\"Student\".\"lastName\",\"Student\".\"middleName\"," +
                "\"Group\".\"name\",\"Team\".\"name\",\"Team\".\"scoreTeam\"" +
                "FROM  \"Student\", \"Group\",\"TeamStudent\",\"Team\"" +
                "WHERE \"Student\".\"studentId\" = \"TeamStudent\".\"studentId\" and \"Student\".\"groupId\" = \"Group\".\"groupId\"" +
                "and \"TeamStudent\".\"teamId\" = \"Team\".\"teamId\"" +
                "and \"Group\".\"name\" = '"+comboBoxSSGroup.Text+"'; ";
            NpgsqlDataReader dr = comm.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            dt.Columns["name"].ColumnName = "Group";
            dt.Columns["name1"].ColumnName = "Team";
            dt.AcceptChanges();
            dt.Columns.Add("MeanScoreByStage");
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                dt.Rows[i]["MeanScoreByStage"] = MeanScoreStageTeam(dt.Rows[i]["Team"].ToString());
            }
            dataGridViewSS.DataSource = dt;
            comm.Dispose();
            nc.Close();
        }
        private double MeanScoreStageTeam(string name)
        {
            string connString = dbsettings.GetConnString();
            NpgsqlConnection nc = new NpgsqlConnection(connString);
            nc.Open();
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = nc;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "SELECT \"ScoreStage\".\"scoreStage\"FROM \"ScoreStage\", \"Team\"" +
                "WHERE \"ScoreStage\".\"teamId\" = \"Team\".\"teamId\"and \"Team\".\"name\" = '"+name+"'; ";
            NpgsqlDataReader dr = comm.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            comm.Dispose();
            double mean = 0;
            int count = 0;
            nc.Close(); if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    if (((dt.Rows[i]["scoreStage"])is int)||(dt.Rows[i]["scoreStage"]) is double)
                    {
                        mean += Convert.ToDouble(dt.Rows[i]["scoreStage"]);
                        count += 1;
                    }
                }
                if (count > 0)
                {
                    return mean / count;
                }
                else
                {
                    return -1;
                }
            }
            else
            {
                return -1;
            }
        }
        
    }
    /*public bool IsNumber(this object obj)
    {
        if (Equals(obj, null))
        {
            return false;
        }

        Type objType = obj.GetType();
        objType = Nullable.GetUnderlyingType(objType) ?? objType;

        if (objType.IsPrimitive)
        {
            return objType != typeof(bool) &&
                objType != typeof(char) &&
                objType != typeof(IntPtr) &&
                objType != typeof(UIntPtr);
        }

        return objType == typeof(decimal);
    }*/
}
