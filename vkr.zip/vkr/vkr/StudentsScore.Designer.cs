﻿namespace vkr
{
    partial class StudentsScore
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.comboBoxSSGroup = new System.Windows.Forms.ComboBox();
            this.dataGridViewSS = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSS)).BeginInit();
            this.SuspendLayout();
            // 
            // comboBoxSSGroup
            // 
            this.comboBoxSSGroup.FormattingEnabled = true;
            this.comboBoxSSGroup.Location = new System.Drawing.Point(13, 13);
            this.comboBoxSSGroup.Name = "comboBoxSSGroup";
            this.comboBoxSSGroup.Size = new System.Drawing.Size(151, 28);
            this.comboBoxSSGroup.TabIndex = 0;
            this.comboBoxSSGroup.SelectedIndexChanged += new System.EventHandler(this.comboBoxSSGroup_SelectedIndexChanged);
            // 
            // dataGridViewSS
            // 
            this.dataGridViewSS.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewSS.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewSS.Location = new System.Drawing.Point(13, 48);
            this.dataGridViewSS.Name = "dataGridViewSS";
            this.dataGridViewSS.RowHeadersWidth = 51;
            this.dataGridViewSS.Size = new System.Drawing.Size(775, 390);
            this.dataGridViewSS.TabIndex = 1;
            this.dataGridViewSS.Text = "dataGridView1";
            // 
            // StudentsScore
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dataGridViewSS);
            this.Controls.Add(this.comboBoxSSGroup);
            this.Name = "StudentsScore";
            this.Text = "Оценки";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSS)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBoxSSGroup;
        private System.Windows.Forms.DataGridView dataGridViewSS;
    }
}