﻿namespace vkr
{
    partial class TextSurveyAnalysis
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.comboBoxGroup = new System.Windows.Forms.ComboBox();
            this.zedGraphControlTSA = new ZedGraph.ZedGraphControl();
            this.dataGridViewTSA = new System.Windows.Forms.DataGridView();
            this.TSABTable = new System.Windows.Forms.Button();
            this.comboBoxSurvey = new System.Windows.Forms.ComboBox();
            this.checkedListBoxTSADictionary = new System.Windows.Forms.CheckedListBox();
            this.TASBGist = new System.Windows.Forms.Button();
            this.buttonTSASelectNoth = new System.Windows.Forms.Button();
            this.buttonTSASelectAll = new System.Windows.Forms.Button();
            this.buttonTSAUpdateDictionary = new System.Windows.Forms.Button();
            this.buttonTSAPolarGraph = new System.Windows.Forms.Button();
            this.buttonTSAStartWLE = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTSA)).BeginInit();
            this.SuspendLayout();
            // 
            // comboBoxGroup
            // 
            this.comboBoxGroup.FormattingEnabled = true;
            this.comboBoxGroup.Location = new System.Drawing.Point(12, 12);
            this.comboBoxGroup.Name = "comboBoxGroup";
            this.comboBoxGroup.Size = new System.Drawing.Size(200, 28);
            this.comboBoxGroup.TabIndex = 0;
            // 
            // zedGraphControlTSA
            // 
            this.zedGraphControlTSA.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.zedGraphControlTSA.Location = new System.Drawing.Point(13, 48);
            this.zedGraphControlTSA.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.zedGraphControlTSA.Name = "zedGraphControlTSA";
            this.zedGraphControlTSA.ScrollGrace = 0D;
            this.zedGraphControlTSA.ScrollMaxX = 0D;
            this.zedGraphControlTSA.ScrollMaxY = 0D;
            this.zedGraphControlTSA.ScrollMaxY2 = 0D;
            this.zedGraphControlTSA.ScrollMinX = 0D;
            this.zedGraphControlTSA.ScrollMinY = 0D;
            this.zedGraphControlTSA.ScrollMinY2 = 0D;
            this.zedGraphControlTSA.Size = new System.Drawing.Size(1052, 644);
            this.zedGraphControlTSA.TabIndex = 1;
            this.zedGraphControlTSA.UseExtendedPrintDialog = true;
            // 
            // dataGridViewTSA
            // 
            this.dataGridViewTSA.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewTSA.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewTSA.Location = new System.Drawing.Point(1072, 48);
            this.dataGridViewTSA.Name = "dataGridViewTSA";
            this.dataGridViewTSA.RowHeadersWidth = 51;
            this.dataGridViewTSA.Size = new System.Drawing.Size(546, 644);
            this.dataGridViewTSA.TabIndex = 2;
            this.dataGridViewTSA.Text = "dataGridView1";
            // 
            // TSABTable
            // 
            this.TSABTable.Location = new System.Drawing.Point(424, 12);
            this.TSABTable.Name = "TSABTable";
            this.TSABTable.Size = new System.Drawing.Size(200, 29);
            this.TSABTable.TabIndex = 3;
            this.TSABTable.Text = "Таблица";
            this.TSABTable.UseVisualStyleBackColor = true;
            this.TSABTable.Click += new System.EventHandler(this.TSABTable_Click);
            // 
            // comboBoxSurvey
            // 
            this.comboBoxSurvey.FormattingEnabled = true;
            this.comboBoxSurvey.Location = new System.Drawing.Point(218, 12);
            this.comboBoxSurvey.Name = "comboBoxSurvey";
            this.comboBoxSurvey.Size = new System.Drawing.Size(200, 28);
            this.comboBoxSurvey.TabIndex = 0;
            // 
            // checkedListBoxTSADictionary
            // 
            this.checkedListBoxTSADictionary.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.checkedListBoxTSADictionary.CheckOnClick = true;
            this.checkedListBoxTSADictionary.FormattingEnabled = true;
            this.checkedListBoxTSADictionary.Location = new System.Drawing.Point(1624, 50);
            this.checkedListBoxTSADictionary.Name = "checkedListBoxTSADictionary";
            this.checkedListBoxTSADictionary.Size = new System.Drawing.Size(270, 642);
            this.checkedListBoxTSADictionary.TabIndex = 4;
            // 
            // TASBGist
            // 
            this.TASBGist.Location = new System.Drawing.Point(630, 12);
            this.TASBGist.Name = "TASBGist";
            this.TASBGist.Size = new System.Drawing.Size(200, 29);
            this.TASBGist.TabIndex = 5;
            this.TASBGist.Text = "Столбиковая диаграмма";
            this.TASBGist.UseVisualStyleBackColor = true;
            this.TASBGist.Click += new System.EventHandler(this.TASBGist_Click);
            // 
            // buttonTSASelectNoth
            // 
            this.buttonTSASelectNoth.Location = new System.Drawing.Point(1660, 13);
            this.buttonTSASelectNoth.Name = "buttonTSASelectNoth";
            this.buttonTSASelectNoth.Size = new System.Drawing.Size(200, 29);
            this.buttonTSASelectNoth.TabIndex = 6;
            this.buttonTSASelectNoth.Text = "Очистить выбор";
            this.buttonTSASelectNoth.UseVisualStyleBackColor = true;
            this.buttonTSASelectNoth.Click += new System.EventHandler(this.buttonTSASelectNoth_Click);
            // 
            // buttonTSASelectAll
            // 
            this.buttonTSASelectAll.Location = new System.Drawing.Point(1454, 13);
            this.buttonTSASelectAll.Name = "buttonTSASelectAll";
            this.buttonTSASelectAll.Size = new System.Drawing.Size(200, 29);
            this.buttonTSASelectAll.TabIndex = 7;
            this.buttonTSASelectAll.Text = "Выбрать все";
            this.buttonTSASelectAll.UseVisualStyleBackColor = true;
            this.buttonTSASelectAll.Click += new System.EventHandler(this.buttonTSASelectAll_Click);
            // 
            // buttonTSAUpdateDictionary
            // 
            this.buttonTSAUpdateDictionary.Location = new System.Drawing.Point(1248, 13);
            this.buttonTSAUpdateDictionary.Name = "buttonTSAUpdateDictionary";
            this.buttonTSAUpdateDictionary.Size = new System.Drawing.Size(200, 29);
            this.buttonTSAUpdateDictionary.TabIndex = 8;
            this.buttonTSAUpdateDictionary.Text = "Обновить словарь";
            this.buttonTSAUpdateDictionary.UseVisualStyleBackColor = true;
            this.buttonTSAUpdateDictionary.Click += new System.EventHandler(this.buttonTSAUpdateDictionary_Click);
            // 
            // buttonTSAPolarGraph
            // 
            this.buttonTSAPolarGraph.Location = new System.Drawing.Point(836, 12);
            this.buttonTSAPolarGraph.Name = "buttonTSAPolarGraph";
            this.buttonTSAPolarGraph.Size = new System.Drawing.Size(200, 29);
            this.buttonTSAPolarGraph.TabIndex = 9;
            this.buttonTSAPolarGraph.Text = "Лепестковая диаграмма";
            this.buttonTSAPolarGraph.UseVisualStyleBackColor = true;
            this.buttonTSAPolarGraph.Click += new System.EventHandler(this.buttonTSAPolarGraph_Click);
            // 
            // buttonTSAStartWLE
            // 
            this.buttonTSAStartWLE.Location = new System.Drawing.Point(1042, 13);
            this.buttonTSAStartWLE.Name = "buttonTSAStartWLE";
            this.buttonTSAStartWLE.Size = new System.Drawing.Size(200, 29);
            this.buttonTSAStartWLE.TabIndex = 10;
            this.buttonTSAStartWLE.Text = "Редактор словаря";
            this.buttonTSAStartWLE.UseVisualStyleBackColor = true;
            this.buttonTSAStartWLE.Click += new System.EventHandler(this.buttonTSAStartWLE_Click);
            // 
            // TextSurveyAnalysis
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1907, 706);
            this.Controls.Add(this.buttonTSAStartWLE);
            this.Controls.Add(this.buttonTSAPolarGraph);
            this.Controls.Add(this.buttonTSAUpdateDictionary);
            this.Controls.Add(this.buttonTSASelectAll);
            this.Controls.Add(this.buttonTSASelectNoth);
            this.Controls.Add(this.TASBGist);
            this.Controls.Add(this.checkedListBoxTSADictionary);
            this.Controls.Add(this.comboBoxSurvey);
            this.Controls.Add(this.TSABTable);
            this.Controls.Add(this.dataGridViewTSA);
            this.Controls.Add(this.zedGraphControlTSA);
            this.Controls.Add(this.comboBoxGroup);
            this.Name = "TextSurveyAnalysis";
            this.Text = "Обработка текстовых анкет";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTSA)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBoxGroup;
        private ZedGraph.ZedGraphControl zedGraphControlTSA;
        private System.Windows.Forms.DataGridView dataGridViewTSA;
        private System.Windows.Forms.Button TSABTable;
        private System.Windows.Forms.ComboBox comboBoxSurvey;
        private System.Windows.Forms.CheckedListBox checkedListBoxTSADictionary;
        private System.Windows.Forms.Button TASBGist;
        private System.Windows.Forms.Button buttonTSASelectNoth;
        private System.Windows.Forms.Button buttonTSASelectAll;
        private System.Windows.Forms.Button buttonTSAUpdateDictionary;
        private System.Windows.Forms.Button buttonTSAPolarGraph;
        private System.Windows.Forms.Button buttonTSAStartWLE;
    }
}