﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ZedGraph;

namespace vkr
{
    public partial class Conflicts : Form
    {
        Settings.DbSettings dbsettings = new Settings.DbSettings();
        public Conflicts()
        {
            InitializeComponent();
            FillCBYear();
            FillCBSemester();
            FillCBDiscipline();
        }

        private void FillCBYear()
        {
            string connString = dbsettings.GetConnString();
            NpgsqlConnection nc = new NpgsqlConnection(connString);
            nc.Open();
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = nc;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "SELECT \"yearCreation\" FROM \"Team\" ;";
            NpgsqlDataReader dr = comm.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (!comboBoxCYear.Items.Contains(dt.Rows[i]["yearCreation"]))
                {
                    comboBoxCYear.Items.Add(dt.Rows[i]["yearCreation"]);
                }
                //comboBoxSSA1.Items.Add(dt.Rows[i]["yearCreation"]);
            }
            comm.Dispose();
            nc.Close();
        }
        private void FillCBSemester()
        {
            comboBoxCSemester.Items.Add("Весенний");
            comboBoxCSemester.Items.Add("Осенний");
        }
        private void FillCBDiscipline()
        {
            string connString = dbsettings.GetConnString();
            NpgsqlConnection nc = new NpgsqlConnection(connString);
            nc.Open();
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = nc;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "SELECT \"name\" FROM \"Discipline\" ;";
            NpgsqlDataReader dr = comm.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                comboBoxCDiscipline.Items.Add(dt.Rows[i]["name"]);
            }
            comm.Dispose();
            nc.Close();
        }

        private void buttonCConflictEditor_Click(object sender, EventArgs e)
        {
            ConflictEditor newForm = new ConflictEditor();
            newForm.Show();
        }

        struct DataForGraf
        {
            public int year;
            public int count;
            public DataForGraf(int y)
            {
                this.year = y;
                this.count = 0;
            }
            public void addC()
            {
                this.count += 1;
            }
        }
        private void buttonCGraph_Click(object sender, EventArgs e)
        {
            zedGraphControlC.GraphPane.CurveList.Clear();

            zedGraphControlC.GraphPane.GraphObjList.Clear();
            zedGraphControlC.GraphPane.Title.Text = "";
            zedGraphControlC.GraphPane.XAxis.Title.Text = "Год";
            zedGraphControlC.GraphPane.YAxis.Title.Text = "Количество распавшихся команд";
            zedGraphControlC.GraphPane.Y2Axis.Title.Text = "";
            zedGraphControlC.GraphPane.XAxis.Type = AxisType.Linear;
            zedGraphControlC.GraphPane.XAxis.Scale.TextLabels = null;
            zedGraphControlC.RestoreScale(zedGraphControlC.GraphPane);

            string connString = dbsettings.GetConnString();
            NpgsqlConnection nc = new NpgsqlConnection(connString);
            nc.Open();
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = nc;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "SELECT \"Team\".\"yearCreation\" FROM \"Team\",\"Conflict\" WHERE \"Team\".\"teamId\"=\"Conflict\".\"teamId\"" +
                " and \"Conflict\".\"broke\"=true; ";
            NpgsqlDataReader dr = comm.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            comm.Dispose();
            nc.Close();
            List<DataForGraf> Dfg = new List<DataForGraf>();
            DataForGraf temp = new DataForGraf(0);
            Dfg.Add(temp);
            bool nn = false;
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                for (int j = 0; j < Dfg.Count; j++)
                {
                    if (Convert.ToInt32(dt.Rows[i]["yearCreation"]) == Dfg[j].year)
                    {
                        Dfg[j].addC();
                        break;
                    }
                    nn = true;
                    /*else
                    {
                        DataForGraf newdfg = new DataForGraf(Convert.ToInt32(dt.Rows[i]["yearCreation"]));
                        newdfg.addC();
                        Dfg.Add(newdfg);
                    }*/
                }
                if (nn == true)
                {
                    DataForGraf newdfg = new DataForGraf(Convert.ToInt32(dt.Rows[i]["yearCreation"]));
                    newdfg.addC();
                    Dfg.Add(newdfg);
                    nn = false;
                }
            }

            List<double> counts = new List<double>();
            List<string> years = new List<string>();
            for (int i = 0; i < Dfg.Count; i++)
            {
                if (Dfg[i].year != 0)
                {
                    counts.Add(Dfg[i].count);
                    years.Add(Dfg[i].year.ToString());
                }

            }
            string name = "Колличество распавшихся команд";
            //MessageBox.Show(counts.ToString());
            zedGraphControlC.GraphPane.Title.Text = name;
            //BarItem graph = zedGraphControlC.GraphPane.AddBar(name, null, counts.ToArray(), Color.Orange);

            LineItem graph = zedGraphControlC.GraphPane.AddCurve(name, null, counts.ToArray(), Color.Red, SymbolType.Diamond);
            zedGraphControlC.GraphPane.XAxis.Type = AxisType.Text;
            zedGraphControlC.GraphPane.XAxis.Scale.TextLabels = years.ToArray();

            /*List<double> counts2 = new List<double>();
            List<string> years2 = new List<string>();
            years2.Add("2020");
            years2.Add("2021");
            counts2.Add(1);
            counts2.Add(1);
            LineItem graph = zedGraphControlC.GraphPane.AddCurve(name, null, counts2.ToArray(), Color.Red, SymbolType.Diamond);
            zedGraphControlC.GraphPane.XAxis.Type = AxisType.Text;
            zedGraphControlC.GraphPane.XAxis.Scale.TextLabels = years2.ToArray();*/

            zedGraphControlC.GraphPane.AxisChange();
            zedGraphControlC.GraphPane.XAxis.Title.Text = "Года";
            zedGraphControlC.GraphPane.YAxis.Title.Text = "Колличество распавшихся команд";
            zedGraphControlC.Invalidate();
        }
        private bool GetSemesterByName(string name)
        {
            if (name == "Весенний")
            {
                return false;
            }
            else { return true; }
        }
        private void buttonCComment_Click(object sender, EventArgs e)
        {
            string connString = dbsettings.GetConnString();
            NpgsqlConnection nc = new NpgsqlConnection(connString);
            nc.Open();
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = nc;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "SELECT \"Team\".\"name\", \"Team\".\"comment\" FROM \"Team\", \"Project\", \"Discipline\" " +
                "WHERE \"Team\".\"projectId\" = \"Project\".\"projectId\" and \"Project\".\"disciplineId\" = \"Discipline\".\"disciplineId\"" +
                "and \"Discipline\".\"name\" = '" + comboBoxCDiscipline.Text + "' and \"Team\".\"yearCreation\"=" + comboBoxCYear.Text + "" +
                "and \"Team\".\"typeSemester\"=" + GetSemesterByName(comboBoxCSemester.Text) + "; ";
            NpgsqlDataReader dr = comm.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            dataGridViewC.DataSource = dt;
            comm.Dispose();
            nc.Close();
        }

        private void buttonCRatio_Click(object sender, EventArgs e)
        {
            int AllTeam, BrokeTeam;
            string connString = dbsettings.GetConnString();
            NpgsqlConnection nc = new NpgsqlConnection(connString);
            nc.Open();
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = nc;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "SELECT \"Team\".\"name\" FROM \"Team\", \"Project\", \"Discipline\" " +
                "WHERE \"Team\".\"projectId\" = \"Project\".\"projectId\" and \"Project\".\"disciplineId\" = \"Discipline\".\"disciplineId\"" +
                "and \"Discipline\".\"name\" = '" + comboBoxCDiscipline.Text + "' and \"Team\".\"yearCreation\"=" + comboBoxCYear.Text + "" +
                "and \"Team\".\"typeSemester\"=" + GetSemesterByName(comboBoxCSemester.Text) + "; ";
            NpgsqlDataReader dr = comm.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            comm.Dispose();
            nc.Close();
            AllTeam = dt.Rows.Count;
            NpgsqlConnection nc2 = new NpgsqlConnection(connString);
            nc.Open();
            NpgsqlCommand comm2 = new NpgsqlCommand();
            comm2.Connection = nc;
            comm2.CommandType = CommandType.Text;
            comm2.CommandText = "SELECT \"Team\".\"name\" FROM \"Team\", \"Project\", \"Discipline\",\"Conflict\" " +
                "WHERE \"Team\".\"projectId\" = \"Project\".\"projectId\" and \"Project\".\"disciplineId\" = \"Discipline\".\"disciplineId\" " +
                "and \"Conflict\".\"teamId\"=\"Team\".\"teamId\" and \"Conflict\".\"broke\"= true " +
                "and \"Discipline\".\"name\" = '" + comboBoxCDiscipline.Text + "' and \"Team\".\"yearCreation\"=" + comboBoxCYear.Text + " " +
                "and \"Team\".\"typeSemester\"=" + GetSemesterByName(comboBoxCSemester.Text) + "; ";
            NpgsqlDataReader dr2 = comm2.ExecuteReader();
            DataTable dt2 = new DataTable();
            dt2.Load(dr);
            comm2.Dispose();
            nc2.Close();
            BrokeTeam = dt2.Rows.Count;
            DataTable rezult = new DataTable();
            rezult.Columns.Add("   ");
            rezult.Columns.Add("Count");
            rezult.Rows.Add("Комад распалось", BrokeTeam);
            rezult.Rows.Add("Комад не распалось", AllTeam - BrokeTeam);
            rezult.Rows.Add("Всего команд", AllTeam);
            dataGridViewC.DataSource = rezult;
        }
        /*struct Conf
        {
            public string name;
            public int bcount;
            public int nbcount;
            public Conf(string n)
            {
                this.name = n;
                this.bcount = 0;
                this.nbcount = 0;
            }
            public void bac()
            {
                bcount += 1;
            }
            public void nbac()
            {
                nbcount += 1;
            }
        }*/
        private List<Conf> GetConfList()
        {
            List<Conf> rezult = new List<Conf>();
            string connString = dbsettings.GetConnString();
            NpgsqlConnection nc = new NpgsqlConnection(connString);
            nc.Open();
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = nc;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "SELECT \"name\" FROM \"TypeConflict\"; ";
            NpgsqlDataReader dr = comm.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                Conf temp = new Conf(dt.Rows[i]["name"].ToString());
                rezult.Add(temp);
            }
            comm.Dispose();
            nc.Close();
            return rezult;
        }
        private void buttonCStatisticConflict_Click(object sender, EventArgs e)
        {
            List<Conf> LC = GetConfList();
            string connString = dbsettings.GetConnString();
            NpgsqlConnection nc = new NpgsqlConnection(connString);
            nc.Open();
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = nc;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "SELECT \"Conflict\".\"broke\",\"TypeConflict\".\"name\" FROM \"Team\", \"Project\", \"Discipline\"," +
                "\"Conflict\" ,\"TypeConflict\" WHERE \"Team\".\"projectId\" = \"Project\".\"projectId\" " +
                "and \"Project\".\"disciplineId\" = \"Discipline\".\"disciplineId\"" +
                "and \"TypeConflict\".\"typeConflictId\" = \"Conflict\".\"typeConflictId\" and \"Conflict\".\"teamId\" = \"Team\".\"teamId\" " +
                "and \"Discipline\".\"name\" = '" + comboBoxCDiscipline.Text + "' and \"Team\".\"yearCreation\"=" + comboBoxCYear.Text + " " +
                "and \"Team\".\"typeSemester\"=" + GetSemesterByName(comboBoxCSemester.Text) + "; ";
            NpgsqlDataReader dr = comm.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            comm.Dispose();
            nc.Close();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                for (int j = 0; j < LC.Count; j++)
                {
                    if (LC[j].name == dt.Rows[i]["name"].ToString())
                    {
                        if (Convert.ToBoolean(dt.Rows[i]["broke"]))
                        {
                            LC[j].bac();
                        }
                        else
                        {
                            LC[j].nbac();
                        }
                        break;
                    }
                }
            }
            DataTable rezult = new DataTable();
            rezult.Columns.Add("TypeConflict");
            rezult.Columns.Add("Распались");
            rezult.Columns.Add("Не распались");
            for (int i = 0; i < LC.Count; i++)
            {
                rezult.Rows.Add(LC[i].name, LC[i].bcount, LC[i].nbcount);
            }
            dataGridViewC.DataSource = rezult;
        }
    }
    class Conf
    {
        public string name;
        public int bcount;
        public int nbcount;
        public Conf(string n)
        {
            this.name = n;
            this.bcount = 0;
            this.nbcount = 0;
        }
        public void bac()
        {
            bcount += 1;
        }
        public void nbac()
        {
            nbcount += 1;
        }
    }
}
