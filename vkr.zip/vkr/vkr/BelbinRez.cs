﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace vkr
{
    public partial class BelbinRez : Form
    {
        Settings.DbSettings dbsettings = new Settings.DbSettings();
        public BelbinRez()
        {
            InitializeComponent();
            FillCBGroup();
        }

        private void FillCBGroup()
        {
            string connString = dbsettings.GetConnString();
            NpgsqlConnection nc = new NpgsqlConnection(connString);
            nc.Open();
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = nc;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "SELECT \"name\" FROM \"Group\" ;";
            NpgsqlDataReader dr = comm.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                comboBoxBRGroup.Items.Add(dt.Rows[i]["name"]);
            }
            comm.Dispose();
            nc.Close();
        }
        private void comboBoxBRGroup_SelectedIndexChanged(object sender, EventArgs e)
        {
            string connString = dbsettings.GetConnString();
            NpgsqlConnection nc = new NpgsqlConnection(connString);
            nc.Open();
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = nc;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "SELECT \"Student\".\"fistName\",\"Student\".\"lastName\",\"Student\".\"middleName\", \"Team\".\"name\"," +
                "\"BelbinRoleStudent\".\"coordinator\",\"BelbinRoleStudent\".\"shaper\",\"BelbinRoleStudent\".\"plant\"," +
                "\"BelbinRoleStudent\".\"evaluator\",\"BelbinRoleStudent\".\"implementer\",\"BelbinRoleStudent\".\"resourceInvestigator\"," +
                "\"BelbinRoleStudent\".\"teamworker\",\"BelbinRoleStudent\".\"comoleterFinisher\"" +
                "FROM \"BelbinRoleStudent\", \"Student\", \"Group\", \"Team\", \"TeamStudent\"" +
                "WHERE \"BelbinRoleStudent\".\"studentId\" = \"Student\".\"studentId\" and \"Student\".\"groupId\" = \"Group\".\"groupId\" and" +
                "\"Student\".\"studentId\" = \"TeamStudent\".\"studentId\" and \"TeamStudent\".\"teamId\" = \"Team\".\"teamId\"" +
                "and \"Group\".\"name\" = '"+comboBoxBRGroup.Text+"'; ";
            NpgsqlDataReader dr = comm.ExecuteReader();
            DataTable dt = new DataTable();
            
            dt.Load(dr);
            dt.Columns["comoleterFinisher"].ColumnName = "completerFinisher";
            dt.Columns["name"].ColumnName = "Team";
            dt.AcceptChanges();
            dataGridViewBR.DataSource = dt;
            comm.Dispose();
            nc.Close();
        }
    }
}
