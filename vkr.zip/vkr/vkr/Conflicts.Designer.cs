﻿namespace vkr
{
    partial class Conflicts
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.comboBoxCYear = new System.Windows.Forms.ComboBox();
            this.comboBoxCSemester = new System.Windows.Forms.ComboBox();
            this.comboBoxCDiscipline = new System.Windows.Forms.ComboBox();
            this.buttonCGraph = new System.Windows.Forms.Button();
            this.buttonCStatisticConflict = new System.Windows.Forms.Button();
            this.buttonCRatio = new System.Windows.Forms.Button();
            this.zedGraphControlC = new ZedGraph.ZedGraphControl();
            this.dataGridViewC = new System.Windows.Forms.DataGridView();
            this.buttonCComment = new System.Windows.Forms.Button();
            this.buttonCConflictEditor = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewC)).BeginInit();
            this.SuspendLayout();
            // 
            // comboBoxCYear
            // 
            this.comboBoxCYear.FormattingEnabled = true;
            this.comboBoxCYear.Location = new System.Drawing.Point(13, 13);
            this.comboBoxCYear.Name = "comboBoxCYear";
            this.comboBoxCYear.Size = new System.Drawing.Size(151, 28);
            this.comboBoxCYear.TabIndex = 0;
            // 
            // comboBoxCSemester
            // 
            this.comboBoxCSemester.FormattingEnabled = true;
            this.comboBoxCSemester.Location = new System.Drawing.Point(171, 13);
            this.comboBoxCSemester.Name = "comboBoxCSemester";
            this.comboBoxCSemester.Size = new System.Drawing.Size(151, 28);
            this.comboBoxCSemester.TabIndex = 1;
            // 
            // comboBoxCDiscipline
            // 
            this.comboBoxCDiscipline.FormattingEnabled = true;
            this.comboBoxCDiscipline.Location = new System.Drawing.Point(329, 13);
            this.comboBoxCDiscipline.Name = "comboBoxCDiscipline";
            this.comboBoxCDiscipline.Size = new System.Drawing.Size(151, 28);
            this.comboBoxCDiscipline.TabIndex = 2;
            // 
            // buttonCGraph
            // 
            this.buttonCGraph.Location = new System.Drawing.Point(487, 13);
            this.buttonCGraph.Name = "buttonCGraph";
            this.buttonCGraph.Size = new System.Drawing.Size(94, 29);
            this.buttonCGraph.TabIndex = 3;
            this.buttonCGraph.Text = "График";
            this.buttonCGraph.UseVisualStyleBackColor = true;
            this.buttonCGraph.Click += new System.EventHandler(this.buttonCGraph_Click);
            // 
            // buttonCStatisticConflict
            // 
            this.buttonCStatisticConflict.Location = new System.Drawing.Point(588, 13);
            this.buttonCStatisticConflict.Name = "buttonCStatisticConflict";
            this.buttonCStatisticConflict.Size = new System.Drawing.Size(178, 29);
            this.buttonCStatisticConflict.TabIndex = 4;
            this.buttonCStatisticConflict.Text = "Статистика конфликтов";
            this.buttonCStatisticConflict.UseVisualStyleBackColor = true;
            this.buttonCStatisticConflict.Click += new System.EventHandler(this.buttonCStatisticConflict_Click);
            // 
            // buttonCRatio
            // 
            this.buttonCRatio.Location = new System.Drawing.Point(772, 12);
            this.buttonCRatio.Name = "buttonCRatio";
            this.buttonCRatio.Size = new System.Drawing.Size(119, 29);
            this.buttonCRatio.TabIndex = 5;
            this.buttonCRatio.Text = "Соотношение";
            this.buttonCRatio.UseVisualStyleBackColor = true;
            this.buttonCRatio.Click += new System.EventHandler(this.buttonCRatio_Click);
            // 
            // zedGraphControlC
            // 
            this.zedGraphControlC.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.zedGraphControlC.Location = new System.Drawing.Point(13, 48);
            this.zedGraphControlC.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.zedGraphControlC.Name = "zedGraphControlC";
            this.zedGraphControlC.ScrollGrace = 0D;
            this.zedGraphControlC.ScrollMaxX = 0D;
            this.zedGraphControlC.ScrollMaxY = 0D;
            this.zedGraphControlC.ScrollMaxY2 = 0D;
            this.zedGraphControlC.ScrollMinX = 0D;
            this.zedGraphControlC.ScrollMinY = 0D;
            this.zedGraphControlC.ScrollMinY2 = 0D;
            this.zedGraphControlC.Size = new System.Drawing.Size(568, 388);
            this.zedGraphControlC.TabIndex = 6;
            this.zedGraphControlC.UseExtendedPrintDialog = true;
            // 
            // dataGridViewC
            // 
            this.dataGridViewC.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewC.Location = new System.Drawing.Point(588, 46);
            this.dataGridViewC.Name = "dataGridViewC";
            this.dataGridViewC.RowHeadersWidth = 51;
            this.dataGridViewC.Size = new System.Drawing.Size(623, 390);
            this.dataGridViewC.TabIndex = 7;
            this.dataGridViewC.Text = "dataGridView1";
            // 
            // buttonCComment
            // 
            this.buttonCComment.Location = new System.Drawing.Point(897, 13);
            this.buttonCComment.Name = "buttonCComment";
            this.buttonCComment.Size = new System.Drawing.Size(129, 29);
            this.buttonCComment.TabIndex = 8;
            this.buttonCComment.Text = "Комментарии";
            this.buttonCComment.UseVisualStyleBackColor = true;
            this.buttonCComment.Click += new System.EventHandler(this.buttonCComment_Click);
            // 
            // buttonCConflictEditor
            // 
            this.buttonCConflictEditor.Location = new System.Drawing.Point(1032, 13);
            this.buttonCConflictEditor.Name = "buttonCConflictEditor";
            this.buttonCConflictEditor.Size = new System.Drawing.Size(179, 29);
            this.buttonCConflictEditor.TabIndex = 9;
            this.buttonCConflictEditor.Text = "Редактор конфликтов";
            this.buttonCConflictEditor.UseVisualStyleBackColor = true;
            this.buttonCConflictEditor.Click += new System.EventHandler(this.buttonCConflictEditor_Click);
            // 
            // Conflicts
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1223, 450);
            this.Controls.Add(this.buttonCConflictEditor);
            this.Controls.Add(this.buttonCComment);
            this.Controls.Add(this.dataGridViewC);
            this.Controls.Add(this.zedGraphControlC);
            this.Controls.Add(this.buttonCRatio);
            this.Controls.Add(this.buttonCStatisticConflict);
            this.Controls.Add(this.buttonCGraph);
            this.Controls.Add(this.comboBoxCDiscipline);
            this.Controls.Add(this.comboBoxCSemester);
            this.Controls.Add(this.comboBoxCYear);
            this.Name = "Conflicts";
            this.Text = "Конфликты";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewC)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBoxCYear;
        private System.Windows.Forms.ComboBox comboBoxCSemester;
        private System.Windows.Forms.ComboBox comboBoxCDiscipline;
        private System.Windows.Forms.Button buttonCGraph;
        private System.Windows.Forms.Button buttonCStatisticConflict;
        private System.Windows.Forms.Button buttonCRatio;
        private ZedGraph.ZedGraphControl zedGraphControlC;
        private System.Windows.Forms.DataGridView dataGridViewC;
        private System.Windows.Forms.Button buttonCComment;
        private System.Windows.Forms.Button buttonCConflictEditor;
    }
}