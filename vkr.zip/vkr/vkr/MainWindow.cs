﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace vkr
{
    public partial class MainWindow : Form
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void MwBTextSurvey_Click(object sender, EventArgs e)
        {
            TextSurveyAnalysis newForm = new TextSurveyAnalysis();
            newForm.Show();
        }

        private void MwBScoreSurvey_Click(object sender, EventArgs e)
        {
            ScoreSurveyAnalysis newForm = new ScoreSurveyAnalysis();
            newForm.Show();
        }

        private void MwBBelbinRez_Click(object sender, EventArgs e)
        {
            BelbinRez newForm = new BelbinRez();
            newForm.Show();
        }

        private void MwBScore_Click(object sender, EventArgs e)
        {
            StudentsScore newForm = new StudentsScore();
            newForm.Show();
        }

        private void MwBScoreTeammate_Click(object sender, EventArgs e)
        {
            SelfScoreTeam newForm = new SelfScoreTeam();
            newForm.Show();
        }

        private void MwBConflict_Click(object sender, EventArgs e)
        {
            Conflicts newForm = new Conflicts();
            newForm.Show();
        }

        private void MwBDBSettings_Click(object sender, EventArgs e)
        {
            DBSettings newForm = new DBSettings();
            newForm.Show();
        }
    }
}
