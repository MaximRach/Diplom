﻿namespace vkr
{
    partial class SelfScoreTeam
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.comboBoxSSTTeam = new System.Windows.Forms.ComboBox();
            this.comboBoxSSTStage = new System.Windows.Forms.ComboBox();
            this.dataGridViewSSTSS = new System.Windows.Forms.DataGridView();
            this.dataGridViewSSTMeanScore = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSSTSS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSSTMeanScore)).BeginInit();
            this.SuspendLayout();
            // 
            // comboBoxSSTTeam
            // 
            this.comboBoxSSTTeam.FormattingEnabled = true;
            this.comboBoxSSTTeam.Location = new System.Drawing.Point(13, 13);
            this.comboBoxSSTTeam.Name = "comboBoxSSTTeam";
            this.comboBoxSSTTeam.Size = new System.Drawing.Size(151, 28);
            this.comboBoxSSTTeam.TabIndex = 0;
            this.comboBoxSSTTeam.SelectedIndexChanged += new System.EventHandler(this.comboBoxSSTTeam_SelectedIndexChanged);
            // 
            // comboBoxSSTStage
            // 
            this.comboBoxSSTStage.FormattingEnabled = true;
            this.comboBoxSSTStage.Location = new System.Drawing.Point(171, 13);
            this.comboBoxSSTStage.Name = "comboBoxSSTStage";
            this.comboBoxSSTStage.Size = new System.Drawing.Size(151, 28);
            this.comboBoxSSTStage.TabIndex = 1;
            this.comboBoxSSTStage.SelectedIndexChanged += new System.EventHandler(this.comboBoxSSTStage_SelectedIndexChanged);
            // 
            // dataGridViewSSTSS
            // 
            this.dataGridViewSSTSS.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewSSTSS.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewSSTSS.Location = new System.Drawing.Point(13, 48);
            this.dataGridViewSSTSS.Name = "dataGridViewSSTSS";
            this.dataGridViewSSTSS.RowHeadersWidth = 51;
            this.dataGridViewSSTSS.Size = new System.Drawing.Size(484, 390);
            this.dataGridViewSSTSS.TabIndex = 2;
            this.dataGridViewSSTSS.Text = "dataGridView1";
            // 
            // dataGridViewSSTMeanScore
            // 
            this.dataGridViewSSTMeanScore.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewSSTMeanScore.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewSSTMeanScore.Location = new System.Drawing.Point(503, 48);
            this.dataGridViewSSTMeanScore.Name = "dataGridViewSSTMeanScore";
            this.dataGridViewSSTMeanScore.RowHeadersWidth = 51;
            this.dataGridViewSSTMeanScore.Size = new System.Drawing.Size(285, 390);
            this.dataGridViewSSTMeanScore.TabIndex = 3;
            this.dataGridViewSSTMeanScore.Text = "dataGridView2";
            // 
            // SelfScoreTeam
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dataGridViewSSTMeanScore);
            this.Controls.Add(this.dataGridViewSSTSS);
            this.Controls.Add(this.comboBoxSSTStage);
            this.Controls.Add(this.comboBoxSSTTeam);
            this.Name = "SelfScoreTeam";
            this.Text = "Самооценка команд";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSSTSS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSSTMeanScore)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBoxSSTTeam;
        private System.Windows.Forms.ComboBox comboBoxSSTStage;
        private System.Windows.Forms.DataGridView dataGridViewSSTSS;
        private System.Windows.Forms.DataGridView dataGridViewSSTMeanScore;
    }
}