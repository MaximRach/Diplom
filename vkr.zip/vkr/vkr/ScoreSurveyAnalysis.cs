﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ZedGraph;

namespace vkr
{
    public partial class ScoreSurveyAnalysis : Form
    {
        Settings.DbSettings dbsettings = new Settings.DbSettings();
        public ScoreSurveyAnalysis()
        {
            InitializeComponent();
            FillCBGroup();
            FillCBSurvey();
        }
        private void FillCBSurvey()
        {
            string connString = dbsettings.GetConnString();
            NpgsqlConnection nc = new NpgsqlConnection(connString);
            nc.Open();
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = nc;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "SELECT \"name\" FROM \"Survey\" ;";
            NpgsqlDataReader dr = comm.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                comboBoxSSASurvey.Items.Add(dt.Rows[i]["name"]);
            }
            comm.Dispose();
            nc.Close();
        }
        private void FillCBGroup()
        {
            comboBoxSSA1.Items.Clear();
            comboBoxSSA2.Items.Clear();
            string connString = dbsettings.GetConnString();
            NpgsqlConnection nc = new NpgsqlConnection(connString);
            nc.Open();
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = nc;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "SELECT \"name\" FROM \"Group\" ;";
            NpgsqlDataReader dr = comm.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                comboBoxSSA1.Items.Add(dt.Rows[i]["name"]);
            }
            comm.Dispose();
            nc.Close();
        }
        private void FillCBTeam()
        {
            comboBoxSSA1.Items.Clear();
            comboBoxSSA2.Items.Clear();
            string connString = dbsettings.GetConnString();
            NpgsqlConnection nc = new NpgsqlConnection(connString);
            nc.Open();
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = nc;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "SELECT \"name\" FROM \"Team\" ;";
            NpgsqlDataReader dr = comm.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                comboBoxSSA1.Items.Add(dt.Rows[i]["name"]);
            }
            comm.Dispose();
            nc.Close();
        }
        private void FillCBDiscipline()
        {
            comboBoxSSA1.Items.Clear();
            comboBoxSSA2.Items.Clear();
            string connString = dbsettings.GetConnString();
            NpgsqlConnection nc = new NpgsqlConnection(connString);
            nc.Open();
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = nc;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "SELECT \"name\" FROM \"Discipline\" ;";
            NpgsqlDataReader dr = comm.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                comboBoxSSA1.Items.Add(dt.Rows[i]["name"]);
            }
            comm.Dispose();
            nc.Close();
        }
        private void FillCBYearandSemester()
        {
            comboBoxSSA1.Items.Clear();
            comboBoxSSA2.Items.Clear();
            string connString = dbsettings.GetConnString();
            NpgsqlConnection nc = new NpgsqlConnection(connString);
            nc.Open();
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = nc;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "SELECT \"yearCreation\" FROM \"Team\" ;";
            NpgsqlDataReader dr = comm.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (!comboBoxSSA1.Items.Contains(dt.Rows[i]["yearCreation"])) {
                    comboBoxSSA1.Items.Add(dt.Rows[i]["yearCreation"]);
                }
                //comboBoxSSA1.Items.Add(dt.Rows[i]["yearCreation"]);
            }
            comboBoxSSA2.Items.Add("Весенний");
            comboBoxSSA2.Items.Add("Осенний");
            comm.Dispose();
            nc.Close();
        }
        private void buttonSSAQuestionWithMinMaxScore_Click(object sender, EventArgs e)
        {
            string connString = dbsettings.GetConnString();
            NpgsqlConnection nc = new NpgsqlConnection(connString);
            nc.Open();
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = nc;
            comm.CommandType = CommandType.Text;
            if (radioButtonSSAGroup.Checked)
            {
                comm.CommandText = "SELECT \"SurveyAnswer2\".\"scoreSurvey\", \"SurveyQuestion2\".\"questionText\",\"SurveyAnswer2\".\"surveyQuestion2Id\""+
                    "FROM \"TeamStudent\", \"Student\", \"Group\",\"SurveyAnswer2\" ,\"SurveyQuestion2\",\"Survey\"" +
                    "WHERE \"SurveyAnswer2\".\"teamStudentId\" = \"TeamStudent\".\"teamStudentId\" and \"TeamStudent\".\"studentId\" = \"Student\".\"studentId\"" +
                    "and \"Student\".\"groupId\" = \"Group\".\"groupId\" and \"SurveyAnswer2\".\"surveyQuestion2Id\" = \"SurveyQuestion2\".\"surveyQuestion2Id\"" +
                    "and \"SurveyQuestion2\".\"surveyId\" = \"Survey\".\"surveyId\"" +
                    "and \"Group\".\"name\" ='"+comboBoxSSA1.Text+"'  and \"Survey\".\"name\" = '"+comboBoxSSASurvey.Text+ "'; ";
            }
            else if(radioButtonSSATeam.Checked)
            {
                comm.CommandText = "SELECT \"SurveyAnswer2\".\"scoreSurvey\", \"SurveyQuestion2\".\"questionText\",\"SurveyAnswer2\".\"surveyQuestion2Id\"" +
                    "FROM \"TeamStudent\", \"Team\",\"SurveyAnswer2\" ,\"SurveyQuestion2\",\"Survey\"" +
                    "WHERE \"SurveyAnswer2\".\"teamStudentId\" = \"TeamStudent\".\"teamStudentId\"" +
                    "and \"TeamStudent\".\"teamId\" = \"Team\".\"teamId\"" +
                    "and \"SurveyAnswer2\".\"surveyQuestion2Id\" = \"SurveyQuestion2\".\"surveyQuestion2Id\"" +
                    "and \"SurveyQuestion2\".\"surveyId\" = \"Survey\".\"surveyId\"" +
                    "and \"Team\".\"name\" = '"+comboBoxSSA1.Text+"' and \"Survey\".\"name\" = '"+comboBoxSSASurvey.Text+"'; ";
            }
            else if(radioButtonSSAYearAndSemester.Checked)
            {
                comm.CommandText = "SELECT \"SurveyAnswer2\".\"scoreSurvey\", \"SurveyQuestion2\".\"questionText\",\"SurveyAnswer2\".\"surveyQuestion2Id\"" +
                    "FROM \"TeamStudent\", \"Team\",\"SurveyAnswer2\" ,\"SurveyQuestion2\",\"Survey\"" +
                    "WHERE \"SurveyAnswer2\".\"teamStudentId\" = \"TeamStudent\".\"teamStudentId\"" +
                    "and \"TeamStudent\".\"teamId\" = \"Team\".\"teamId\"" +
                    "and \"SurveyAnswer2\".\"surveyQuestion2Id\" = \"SurveyQuestion2\".\"surveyQuestion2Id\"" +
                    "and \"SurveyQuestion2\".\"surveyId\" = \"Survey\".\"surveyId\"" +
                    "and \"Team\".\"yearCreation\" ="+ comboBoxSSA1.Text+" and \"Team\".\"typeSemester\" ="+ CheckSemester() + " "+
                    "and \"Survey\".\"name\" = '" + comboBoxSSASurvey.Text + "';" ;
            }
            else
            {
                comm.CommandText = "SELECT \"SurveyAnswer2\".\"scoreSurvey\", \"SurveyQuestion2\".\"questionText\",\"SurveyAnswer2\".\"surveyQuestion2Id\" " +
                    "FROM \"TeamStudent\", \"Team\",\"SurveyAnswer2\" ,\"SurveyQuestion2\",\"Survey\", \"Project\",\"Discipline\" "+
                    "WHERE \"SurveyAnswer2\".\"teamStudentId\" = \"TeamStudent\".\"teamStudentId\" " +
                    "and \"TeamStudent\".\"teamId\" = \"Team\".\"teamId\" " +
                    "and \"SurveyAnswer2\".\"surveyQuestion2Id\" = \"SurveyQuestion2\".\"surveyQuestion2Id\" " +
                    "and \"SurveyQuestion2\".\"surveyId\" = \"Survey\".\"surveyId\" " +
                    "and \"Team\".\"projectId\" = \"Project\".\"projectId\" and \"Project\".\"disciplineId\" = \"Discipline\".\"disciplineId\" "+
                    "and \"Discipline\".\"name\" ='" + comboBoxSSA1.Text + "' "+
                    "and \"Survey\".\"name\" = '" + comboBoxSSASurvey.Text + "';";
            }
            //comm.CommandText = "SELECT \"name\" FROM \"Group\" ;";
            NpgsqlDataReader dr = comm.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            //dataGridViewSSAMaxScoreQuestion.DataSource = dt;
            comm.Dispose();
            nc.Close();
            ScoreAnswerAnalysis SAATemp = new ScoreAnswerAnalysis();
            SAATemp.FindAndCount(dt);
            dataGridViewSSAMaxScoreQuestion.DataSource = SAATemp.Find3Max();
            dataGridViewSSAMinScoreQuestion.DataSource = SAATemp.Find3Min();
        }

        private string CheckSemester()
        {
            if (comboBoxSSA2.Text== "Весенний")
            {
                return "false";
            }
            else
            {
                return "true";
            }
        }
        private void radioButtonSSAGroup_CheckedChanged(object sender, EventArgs e)
        {
            FillCBGroup();
        }

        private void radioButtonSSATeam_CheckedChanged(object sender, EventArgs e)
        {
            FillCBTeam();
        }

        private void radioButtonSSAYearAndSemester_CheckedChanged(object sender, EventArgs e)
        {
            FillCBYearandSemester();
        }

        private void radioButtonSSADiscipline_CheckedChanged(object sender, EventArgs e)
        {
            FillCBDiscipline();
        }

        private void buttonSSAGraph_Click(object sender, EventArgs e)
        {
            ListSudent LS = new ListSudent();
            LS.FindAndCount(GetDataTableForGraph());
            DataTable dt = LS.GetDataForGraph();
            //dataGridViewSSAMaxScoreQuestion.DataSource = LS.GetDataForGraph();

            zedGraphControlSSA.GraphPane.CurveList.Clear();

            zedGraphControlSSA.GraphPane.GraphObjList.Clear();
            zedGraphControlSSA.GraphPane.Title.Text = "";
            zedGraphControlSSA.GraphPane.XAxis.Title.Text = "";
            zedGraphControlSSA.GraphPane.YAxis.Title.Text = "";
            zedGraphControlSSA.GraphPane.Y2Axis.Title.Text = "";
            zedGraphControlSSA.GraphPane.XAxis.Type = AxisType.Linear;
            zedGraphControlSSA.GraphPane.XAxis.Scale.TextLabels = null;
            zedGraphControlSSA.RestoreScale(zedGraphControlSSA.GraphPane);

            List<double> xStudent = new List<double> { };
            List<double> yMean = new List<double> { };
            for (int i=0; i<dt.Rows.Count-1;i++)
            {
                xStudent.Add(Convert.ToDouble(dt.Rows[i]["CountStudent"]));
                yMean.Add(Convert.ToDouble(dt.Rows[i]["MeanScore"]));
            }
            LineItem graph = zedGraphControlSSA.GraphPane.AddCurve("Анкета:"+comboBoxSSASurvey.Text+" ,"+comboBoxSSA1.Text, xStudent.ToArray(), yMean.ToArray(), Color.Red, SymbolType.Diamond);
            zedGraphControlSSA.GraphPane.XAxis.Title.Text = "Анкета:" + comboBoxSSASurvey.Text + " ," + comboBoxSSA1.Text;

            zedGraphControlSSA.GraphPane.AxisChange();
            zedGraphControlSSA.Invalidate();
        }

        private DataTable GetDataTableForGraph()
        {
            string connString = dbsettings.GetConnString();
            NpgsqlConnection nc = new NpgsqlConnection(connString);
            nc.Open();
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = nc;
            comm.CommandType = CommandType.Text;
            if (radioButtonSSAGroup.Checked)
            {
                comm.CommandText = "SELECT \"SurveyAnswer2\".\"scoreSurvey\", \"TeamStudent\".\"studentId\",\"SurveyAnswer2\".\"surveyQuestion2Id\"" +
                    "FROM \"TeamStudent\", \"Student\", \"Group\",\"SurveyAnswer2\" ,\"SurveyQuestion2\",\"Survey\"" +
                    "WHERE \"SurveyAnswer2\".\"teamStudentId\" = \"TeamStudent\".\"teamStudentId\" and \"TeamStudent\".\"studentId\" = \"Student\".\"studentId\"" +
                    "and \"Student\".\"groupId\" = \"Group\".\"groupId\" and \"SurveyAnswer2\".\"surveyQuestion2Id\" = \"SurveyQuestion2\".\"surveyQuestion2Id\"" +
                    "and \"SurveyQuestion2\".\"surveyId\" = \"Survey\".\"surveyId\"" +
                    "and \"Group\".\"name\" ='" + comboBoxSSA1.Text + "'  and \"Survey\".\"name\" = '" + comboBoxSSASurvey.Text + "'; ";
            }
            else if (radioButtonSSATeam.Checked)
            {
                comm.CommandText = "SELECT \"SurveyAnswer2\".\"scoreSurvey\", \"TeamStudent\".\"studentId\",\"SurveyAnswer2\".\"surveyQuestion2Id\"" +
                    "FROM \"TeamStudent\", \"Team\",\"SurveyAnswer2\" ,\"SurveyQuestion2\",\"Survey\"" +
                    "WHERE \"SurveyAnswer2\".\"teamStudentId\" = \"TeamStudent\".\"teamStudentId\"" +
                    "and \"TeamStudent\".\"teamId\" = \"Team\".\"teamId\"" +
                    "and \"SurveyAnswer2\".\"surveyQuestion2Id\" = \"SurveyQuestion2\".\"surveyQuestion2Id\"" +
                    "and \"SurveyQuestion2\".\"surveyId\" = \"Survey\".\"surveyId\"" +
                    "and \"Team\".\"name\" = '" + comboBoxSSA1.Text + "' and \"Survey\".\"name\" = '" + comboBoxSSASurvey.Text + "'; ";
            }
            else if (radioButtonSSAYearAndSemester.Checked)
            {
                comm.CommandText = "SELECT \"SurveyAnswer2\".\"scoreSurvey\", \"TeamStudent\".\"studentId\",\"SurveyAnswer2\".\"surveyQuestion2Id\"" +
                    "FROM \"TeamStudent\", \"Team\",\"SurveyAnswer2\" ,\"SurveyQuestion2\",\"Survey\"" +
                    "WHERE \"SurveyAnswer2\".\"teamStudentId\" = \"TeamStudent\".\"teamStudentId\"" +
                    "and \"TeamStudent\".\"teamId\" = \"Team\".\"teamId\"" +
                    "and \"SurveyAnswer2\".\"surveyQuestion2Id\" = \"SurveyQuestion2\".\"surveyQuestion2Id\"" +
                    "and \"SurveyQuestion2\".\"surveyId\" = \"Survey\".\"surveyId\"" +
                    "and \"Team\".\"yearCreation\" =" + comboBoxSSA1.Text + " and \"Team\".\"typeSemester\" =" + CheckSemester() + " " +
                    "and \"Survey\".\"name\" = '" + comboBoxSSASurvey.Text + "';";
            }
            else
            {
                comm.CommandText = "SELECT \"SurveyAnswer2\".\"scoreSurvey\", \"TeamStudent\".\"studentId\",\"SurveyAnswer2\".\"surveyQuestion2Id\" " +
                    "FROM \"TeamStudent\", \"Team\",\"SurveyAnswer2\" ,\"SurveyQuestion2\",\"Survey\", \"Project\",\"Discipline\" " +
                    "WHERE \"SurveyAnswer2\".\"teamStudentId\" = \"TeamStudent\".\"teamStudentId\" " +
                    "and \"TeamStudent\".\"teamId\" = \"Team\".\"teamId\" " +
                    "and \"SurveyAnswer2\".\"surveyQuestion2Id\" = \"SurveyQuestion2\".\"surveyQuestion2Id\" " +
                    "and \"SurveyQuestion2\".\"surveyId\" = \"Survey\".\"surveyId\" " +
                    "and \"Team\".\"projectId\" = \"Project\".\"projectId\" and \"Project\".\"disciplineId\" = \"Discipline\".\"disciplineId\" " +
                    "and \"Discipline\".\"name\" ='" + comboBoxSSA1.Text + "' " +
                    "and \"Survey\".\"name\" = '" + comboBoxSSASurvey.Text + "';";
            }
            //comm.CommandText = "SELECT \"name\" FROM \"Group\" ;";
            NpgsqlDataReader dr = comm.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            //dataGridViewSSAMaxScoreQuestion.DataSource = dt;
            comm.Dispose();
            nc.Close();
            return dt;
        }

        private void buttonSSAGist_Click(object sender, EventArgs e)
        {
            ListSudent LS = new ListSudent();
            LS.FindAndCount(GetDataTableForGraph());
            DataTable dt = LS.GetDataForGraph();
            //dataGridViewSSAMaxScoreQuestion.DataSource = LS.GetDataForGraph();

            zedGraphControlSSA.GraphPane.CurveList.Clear();

            zedGraphControlSSA.GraphPane.GraphObjList.Clear();
            zedGraphControlSSA.GraphPane.Title.Text = "";
            zedGraphControlSSA.GraphPane.XAxis.Title.Text = "";
            zedGraphControlSSA.GraphPane.YAxis.Title.Text = "";
            zedGraphControlSSA.GraphPane.Y2Axis.Title.Text = "";
            zedGraphControlSSA.GraphPane.XAxis.Type = AxisType.Linear;
            zedGraphControlSSA.GraphPane.XAxis.Scale.TextLabels = null;
            zedGraphControlSSA.RestoreScale(zedGraphControlSSA.GraphPane);
            List<double> xStudent = new List<double> { };
            List<double> yMean = new List<double> { };
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                xStudent.Add(Convert.ToDouble(dt.Rows[i]["CountStudent"]));
                yMean.Add(Convert.ToDouble(dt.Rows[i]["MeanScore"]));
            }
            string name = "Анкета:" + comboBoxSSASurvey.Text + " ," + comboBoxSSA1.Text;
            zedGraphControlSSA.GraphPane.Title.Text = name;
            BarItem graph = zedGraphControlSSA.GraphPane.AddBar(name, null, yMean.ToArray(), Color.Orange);
            zedGraphControlSSA.GraphPane.XAxis.Type = AxisType.Text;
            zedGraphControlSSA.GraphPane.XAxis.Scale.TextLabels = (LDTMS(xStudent));
            zedGraphControlSSA.GraphPane.AxisChange();
            zedGraphControlSSA.GraphPane.XAxis.Title.Text = "Выбранные слова";
            zedGraphControlSSA.GraphPane.YAxis.Title.Text = "Колличество слов";
            zedGraphControlSSA.Invalidate();
        }
        private string[] LDTMS(List<Double> l)
        {
            List<string> t = new List<string>();
            for (int i = 0; i < l.Count; i++)
            {
                t.Add(l[i].ToString());
            }
            return t.ToArray();
        }
    }
}
