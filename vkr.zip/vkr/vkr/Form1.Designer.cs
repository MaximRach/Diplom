﻿namespace vkr
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.GL1 = new ZedGraph.ZedGraphControl();
            this.button1 = new System.Windows.Forms.Button();
            this.checkedListBox1 = new System.Windows.Forms.CheckedListBox();
            this.WordsListEditorButton = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.polarplotbutton = new System.Windows.Forms.Button();
            this.gistbutton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // GL1
            // 
            this.GL1.Location = new System.Drawing.Point(0, 0);
            this.GL1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.GL1.Name = "GL1";
            this.GL1.ScrollGrace = 0D;
            this.GL1.ScrollMaxX = 0D;
            this.GL1.ScrollMaxY = 0D;
            this.GL1.ScrollMaxY2 = 0D;
            this.GL1.ScrollMinX = 0D;
            this.GL1.ScrollMinY = 0D;
            this.GL1.ScrollMinY2 = 0D;
            this.GL1.Size = new System.Drawing.Size(688, 450);
            this.GL1.TabIndex = 0;
            this.GL1.UseExtendedPrintDialog = true;
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.Location = new System.Drawing.Point(696, 13);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(253, 29);
            this.button1.TabIndex = 1;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // checkedListBox1
            // 
            this.checkedListBox1.CheckOnClick = true;
            this.checkedListBox1.FormattingEnabled = true;
            this.checkedListBox1.Location = new System.Drawing.Point(696, 49);
            this.checkedListBox1.Name = "checkedListBox1";
            this.checkedListBox1.Size = new System.Drawing.Size(150, 114);
            this.checkedListBox1.TabIndex = 2;
            // 
            // WordsListEditorButton
            // 
            this.WordsListEditorButton.Location = new System.Drawing.Point(696, 213);
            this.WordsListEditorButton.Name = "WordsListEditorButton";
            this.WordsListEditorButton.Size = new System.Drawing.Size(172, 29);
            this.WordsListEditorButton.TabIndex = 3;
            this.WordsListEditorButton.Text = "WordsListEditor";
            this.WordsListEditorButton.UseVisualStyleBackColor = true;
            this.WordsListEditorButton.Click += new System.EventHandler(this.WordsListEditorButton_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(855, 134);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(94, 29);
            this.button2.TabIndex = 4;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(686, 273);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.Size = new System.Drawing.Size(300, 188);
            this.dataGridView1.TabIndex = 5;
            this.dataGridView1.Text = "dataGridView1";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(250, 470);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(125, 27);
            this.textBox1.TabIndex = 6;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(855, 170);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(94, 29);
            this.button3.TabIndex = 7;
            this.button3.Text = "button3";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(449, 470);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(94, 29);
            this.button5.TabIndex = 8;
            this.button5.Text = "button5";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // polarplotbutton
            // 
            this.polarplotbutton.Location = new System.Drawing.Point(643, 484);
            this.polarplotbutton.Name = "polarplotbutton";
            this.polarplotbutton.Size = new System.Drawing.Size(94, 29);
            this.polarplotbutton.TabIndex = 9;
            this.polarplotbutton.Text = "polarplot";
            this.polarplotbutton.UseVisualStyleBackColor = true;
            this.polarplotbutton.Click += new System.EventHandler(this.polarplotbutton_Click);
            // 
            // gistbutton
            // 
            this.gistbutton.Location = new System.Drawing.Point(744, 484);
            this.gistbutton.Name = "gistbutton";
            this.gistbutton.Size = new System.Drawing.Size(94, 29);
            this.gistbutton.TabIndex = 10;
            this.gistbutton.Text = "gist";
            this.gistbutton.UseVisualStyleBackColor = true;
            this.gistbutton.Click += new System.EventHandler(this.gistbutton_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(959, 525);
            this.Controls.Add(this.gistbutton);
            this.Controls.Add(this.polarplotbutton);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.WordsListEditorButton);
            this.Controls.Add(this.checkedListBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.GL1);
            this.Name = "MainForm";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ZedGraph.ZedGraphControl zedGraphControl1;
        private System.Windows.Forms.Button button1;
        private ZedGraph.ZedGraphControl GL1;
        private System.Windows.Forms.CheckedListBox checkedListBox1;
        private System.Windows.Forms.Button WordsListEditorButton;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button polarplotbutton;
        private System.Windows.Forms.Button gistbutton;
    }
}

