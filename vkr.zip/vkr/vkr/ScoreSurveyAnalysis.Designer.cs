﻿namespace vkr
{
    partial class ScoreSurveyAnalysis
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.radioButtonSSAGroup = new System.Windows.Forms.RadioButton();
            this.radioButtonSSATeam = new System.Windows.Forms.RadioButton();
            this.radioButtonSSAYearAndSemester = new System.Windows.Forms.RadioButton();
            this.radioButtonSSADiscipline = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBoxSSA1 = new System.Windows.Forms.ComboBox();
            this.comboBoxSSA2 = new System.Windows.Forms.ComboBox();
            this.comboBoxSSASurvey = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.buttonSSAQuestionWithMinMaxScore = new System.Windows.Forms.Button();
            this.buttonSSAGraph = new System.Windows.Forms.Button();
            this.buttonSSAGist = new System.Windows.Forms.Button();
            this.dataGridViewSSAMinScoreQuestion = new System.Windows.Forms.DataGridView();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.dataGridViewSSAMaxScoreQuestion = new System.Windows.Forms.DataGridView();
            this.zedGraphControlSSA = new ZedGraph.ZedGraphControl();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSSAMinScoreQuestion)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSSAMaxScoreQuestion)).BeginInit();
            this.SuspendLayout();
            // 
            // radioButtonSSAGroup
            // 
            this.radioButtonSSAGroup.AutoSize = true;
            this.radioButtonSSAGroup.Location = new System.Drawing.Point(13, 36);
            this.radioButtonSSAGroup.Name = "radioButtonSSAGroup";
            this.radioButtonSSAGroup.Size = new System.Drawing.Size(78, 24);
            this.radioButtonSSAGroup.TabIndex = 0;
            this.radioButtonSSAGroup.TabStop = true;
            this.radioButtonSSAGroup.Text = "группе";
            this.radioButtonSSAGroup.UseVisualStyleBackColor = true;
            this.radioButtonSSAGroup.CheckedChanged += new System.EventHandler(this.radioButtonSSAGroup_CheckedChanged);
            // 
            // radioButtonSSATeam
            // 
            this.radioButtonSSATeam.AutoSize = true;
            this.radioButtonSSATeam.Location = new System.Drawing.Point(13, 66);
            this.radioButtonSSATeam.Name = "radioButtonSSATeam";
            this.radioButtonSSATeam.Size = new System.Drawing.Size(90, 24);
            this.radioButtonSSATeam.TabIndex = 1;
            this.radioButtonSSATeam.TabStop = true;
            this.radioButtonSSATeam.Text = "команде";
            this.radioButtonSSATeam.UseVisualStyleBackColor = true;
            this.radioButtonSSATeam.CheckedChanged += new System.EventHandler(this.radioButtonSSATeam_CheckedChanged);
            // 
            // radioButtonSSAYearAndSemester
            // 
            this.radioButtonSSAYearAndSemester.AutoSize = true;
            this.radioButtonSSAYearAndSemester.Location = new System.Drawing.Point(13, 96);
            this.radioButtonSSAYearAndSemester.Name = "radioButtonSSAYearAndSemester";
            this.radioButtonSSAYearAndSemester.Size = new System.Drawing.Size(140, 24);
            this.radioButtonSSAYearAndSemester.TabIndex = 2;
            this.radioButtonSSAYearAndSemester.TabStop = true;
            this.radioButtonSSAYearAndSemester.Text = "году и семестру";
            this.radioButtonSSAYearAndSemester.UseVisualStyleBackColor = true;
            this.radioButtonSSAYearAndSemester.CheckedChanged += new System.EventHandler(this.radioButtonSSAYearAndSemester_CheckedChanged);
            // 
            // radioButtonSSADiscipline
            // 
            this.radioButtonSSADiscipline.AutoSize = true;
            this.radioButtonSSADiscipline.Location = new System.Drawing.Point(13, 126);
            this.radioButtonSSADiscipline.Name = "radioButtonSSADiscipline";
            this.radioButtonSSADiscipline.Size = new System.Drawing.Size(96, 24);
            this.radioButtonSSADiscipline.TabIndex = 3;
            this.radioButtonSSADiscipline.TabStop = true;
            this.radioButtonSSADiscipline.Text = "предмету";
            this.radioButtonSSADiscipline.UseVisualStyleBackColor = true;
            this.radioButtonSSADiscipline.CheckedChanged += new System.EventHandler(this.radioButtonSSADiscipline_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 20);
            this.label1.TabIndex = 4;
            this.label1.Text = "Анализ по:";
            // 
            // comboBoxSSA1
            // 
            this.comboBoxSSA1.FormattingEnabled = true;
            this.comboBoxSSA1.Location = new System.Drawing.Point(191, 36);
            this.comboBoxSSA1.Name = "comboBoxSSA1";
            this.comboBoxSSA1.Size = new System.Drawing.Size(151, 28);
            this.comboBoxSSA1.TabIndex = 5;
            // 
            // comboBoxSSA2
            // 
            this.comboBoxSSA2.FormattingEnabled = true;
            this.comboBoxSSA2.Location = new System.Drawing.Point(191, 71);
            this.comboBoxSSA2.Name = "comboBoxSSA2";
            this.comboBoxSSA2.Size = new System.Drawing.Size(151, 28);
            this.comboBoxSSA2.TabIndex = 6;
            // 
            // comboBoxSSASurvey
            // 
            this.comboBoxSSASurvey.FormattingEnabled = true;
            this.comboBoxSSASurvey.Location = new System.Drawing.Point(415, 36);
            this.comboBoxSSASurvey.Name = "comboBoxSSASurvey";
            this.comboBoxSSASurvey.Size = new System.Drawing.Size(151, 28);
            this.comboBoxSSASurvey.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(415, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 20);
            this.label2.TabIndex = 8;
            this.label2.Text = "Анкета:";
            // 
            // buttonSSAQuestionWithMinMaxScore
            // 
            this.buttonSSAQuestionWithMinMaxScore.Location = new System.Drawing.Point(589, 13);
            this.buttonSSAQuestionWithMinMaxScore.Name = "buttonSSAQuestionWithMinMaxScore";
            this.buttonSSAQuestionWithMinMaxScore.Size = new System.Drawing.Size(127, 29);
            this.buttonSSAQuestionWithMinMaxScore.TabIndex = 9;
            this.buttonSSAQuestionWithMinMaxScore.Text = "Мин/макс";
            this.buttonSSAQuestionWithMinMaxScore.UseVisualStyleBackColor = true;
            this.buttonSSAQuestionWithMinMaxScore.Click += new System.EventHandler(this.buttonSSAQuestionWithMinMaxScore_Click);
            // 
            // buttonSSAGraph
            // 
            this.buttonSSAGraph.Location = new System.Drawing.Point(589, 49);
            this.buttonSSAGraph.Name = "buttonSSAGraph";
            this.buttonSSAGraph.Size = new System.Drawing.Size(127, 29);
            this.buttonSSAGraph.TabIndex = 10;
            this.buttonSSAGraph.Text = "График";
            this.buttonSSAGraph.UseVisualStyleBackColor = true;
            this.buttonSSAGraph.Click += new System.EventHandler(this.buttonSSAGraph_Click);
            // 
            // buttonSSAGist
            // 
            this.buttonSSAGist.Location = new System.Drawing.Point(589, 85);
            this.buttonSSAGist.Name = "buttonSSAGist";
            this.buttonSSAGist.Size = new System.Drawing.Size(127, 29);
            this.buttonSSAGist.TabIndex = 11;
            this.buttonSSAGist.Text = "Гистограмма";
            this.buttonSSAGist.UseVisualStyleBackColor = true;
            this.buttonSSAGist.Click += new System.EventHandler(this.buttonSSAGist_Click);
            // 
            // dataGridViewSSAMinScoreQuestion
            // 
            this.dataGridViewSSAMinScoreQuestion.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewSSAMinScoreQuestion.Location = new System.Drawing.Point(13, 176);
            this.dataGridViewSSAMinScoreQuestion.Name = "dataGridViewSSAMinScoreQuestion";
            this.dataGridViewSSAMinScoreQuestion.RowHeadersWidth = 51;
            this.dataGridViewSSAMinScoreQuestion.Size = new System.Drawing.Size(300, 132);
            this.dataGridViewSSAMinScoreQuestion.TabIndex = 12;
            this.dataGridViewSSAMinScoreQuestion.Text = "dataGridView1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 153);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(316, 20);
            this.label3.TabIndex = 13;
            this.label3.Text = "Вопросы с минимальным средним баллом:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 311);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(320, 20);
            this.label4.TabIndex = 13;
            this.label4.Text = "Вопросы с максимальным средним баллом:";
            // 
            // dataGridViewSSAMaxScoreQuestion
            // 
            this.dataGridViewSSAMaxScoreQuestion.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewSSAMaxScoreQuestion.Location = new System.Drawing.Point(13, 334);
            this.dataGridViewSSAMaxScoreQuestion.Name = "dataGridViewSSAMaxScoreQuestion";
            this.dataGridViewSSAMaxScoreQuestion.RowHeadersWidth = 51;
            this.dataGridViewSSAMaxScoreQuestion.Size = new System.Drawing.Size(300, 132);
            this.dataGridViewSSAMaxScoreQuestion.TabIndex = 12;
            this.dataGridViewSSAMaxScoreQuestion.Text = "dataGridView2";
            // 
            // zedGraphControlSSA
            // 
            this.zedGraphControlSSA.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.zedGraphControlSSA.Location = new System.Drawing.Point(357, 176);
            this.zedGraphControlSSA.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.zedGraphControlSSA.Name = "zedGraphControlSSA";
            this.zedGraphControlSSA.ScrollGrace = 0D;
            this.zedGraphControlSSA.ScrollMaxX = 0D;
            this.zedGraphControlSSA.ScrollMaxY = 0D;
            this.zedGraphControlSSA.ScrollMaxY2 = 0D;
            this.zedGraphControlSSA.ScrollMinX = 0D;
            this.zedGraphControlSSA.ScrollMinY = 0D;
            this.zedGraphControlSSA.ScrollMinY2 = 0D;
            this.zedGraphControlSSA.Size = new System.Drawing.Size(429, 289);
            this.zedGraphControlSSA.TabIndex = 14;
            this.zedGraphControlSSA.UseExtendedPrintDialog = true;
            // 
            // ScoreSurveyAnalysis
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(799, 479);
            this.Controls.Add(this.zedGraphControlSSA);
            this.Controls.Add(this.dataGridViewSSAMaxScoreQuestion);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dataGridViewSSAMinScoreQuestion);
            this.Controls.Add(this.buttonSSAGist);
            this.Controls.Add(this.buttonSSAGraph);
            this.Controls.Add(this.buttonSSAQuestionWithMinMaxScore);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.comboBoxSSASurvey);
            this.Controls.Add(this.comboBoxSSA2);
            this.Controls.Add(this.comboBoxSSA1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.radioButtonSSADiscipline);
            this.Controls.Add(this.radioButtonSSAYearAndSemester);
            this.Controls.Add(this.radioButtonSSATeam);
            this.Controls.Add(this.radioButtonSSAGroup);
            this.Name = "ScoreSurveyAnalysis";
            this.Text = "Обработка балльных анкет";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSSAMinScoreQuestion)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSSAMaxScoreQuestion)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton radioButtonSSAGroup;
        private System.Windows.Forms.RadioButton radioButtonSSATeam;
        private System.Windows.Forms.RadioButton radioButtonSSAYearAndSemester;
        private System.Windows.Forms.RadioButton radioButtonSSADiscipline;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBoxSSA1;
        private System.Windows.Forms.ComboBox comboBoxSSA2;
        private System.Windows.Forms.ComboBox comboBoxSSASurvey;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button buttonSSAQuestionWithMinMaxScore;
        private System.Windows.Forms.Button buttonSSAGraph;
        private System.Windows.Forms.Button buttonSSAGist;
        private System.Windows.Forms.DataGridView dataGridViewSSAMinScoreQuestion;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView dataGridViewSSAMaxScoreQuestion;
        private ZedGraph.ZedGraphControl zedGraphControlSSA;
    }
}