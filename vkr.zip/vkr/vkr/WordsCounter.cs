﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Text.RegularExpressions;

namespace vkr
{
    class WordsCounter
    {
        private List<WordCounter> WordList = new List<WordCounter>();
        public void AddWord(WordCounter newWord)
        {
            this.WordList.Add(newWord);
        }
        public void FindAndCount(string text)
        {
            foreach (WordCounter word in this.WordList)
            {
                //word.Count = text.Split(new string[] { word.Word }, StringSplitOptions.None);
                word.Count = new Regex(word.Word).Matches(text).Count;
            }
        }
        public DataTable ToDataTable(double len)
        {
            DataTable rez = new DataTable();
            rez.Columns.Add("Category");
            rez.Columns.Add("Word");
            rez.Columns.Add("Count");
            rez.Columns.Add("Frequency");
            foreach (WordCounter word in this.WordList)
            {
                //rez.Rows.Add(word.ToMObject(),word.Count/len);
                rez.Rows.Add(word.Category,word.Word,word.Count, Convert.ToDouble(word.Count) / len);
                //rez.
            }
            return rez;
        }
        public int Length()
        {
            return WordList.Count;
        }
    }
    class WordCounter
    {
        public string Category;
        public string Word;
        public int Count = 0;
        public void EditWord(string category, string word, int count=0)
        {
            this.Category = category;
            this.Word = word.ToLower();
            this.Count = count;
        }
        public object[] ToMObject()
        {
            return new object[3] {this.Category,this.Word,this.Count  };
        }
    }
}
