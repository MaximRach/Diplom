﻿namespace vkr
{
    partial class WordsListEditor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.InputCategory = new System.Windows.Forms.TextBox();
            this.comboBoxCategory = new System.Windows.Forms.ComboBox();
            this.AddCategory = new System.Windows.Forms.Button();
            this.DelCategory = new System.Windows.Forms.Button();
            this.InputWord = new System.Windows.Forms.TextBox();
            this.comboBoxCategory2 = new System.Windows.Forms.ComboBox();
            this.AddWord = new System.Windows.Forms.Button();
            this.comboBoxCategory3 = new System.Windows.Forms.ComboBox();
            this.comboBoxWord = new System.Windows.Forms.ComboBox();
            this.DelWord = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // InputCategory
            // 
            this.InputCategory.Location = new System.Drawing.Point(14, 61);
            this.InputCategory.Name = "InputCategory";
            this.InputCategory.Size = new System.Drawing.Size(307, 27);
            this.InputCategory.TabIndex = 0;
            // 
            // comboBoxCategory
            // 
            this.comboBoxCategory.FormattingEnabled = true;
            this.comboBoxCategory.Location = new System.Drawing.Point(14, 97);
            this.comboBoxCategory.Name = "comboBoxCategory";
            this.comboBoxCategory.Size = new System.Drawing.Size(307, 28);
            this.comboBoxCategory.TabIndex = 1;
            // 
            // AddCategory
            // 
            this.AddCategory.Location = new System.Drawing.Point(326, 61);
            this.AddCategory.Name = "AddCategory";
            this.AddCategory.Size = new System.Drawing.Size(94, 29);
            this.AddCategory.TabIndex = 2;
            this.AddCategory.Text = "Добавить";
            this.AddCategory.UseVisualStyleBackColor = true;
            this.AddCategory.Click += new System.EventHandler(this.AddCategory_Click);
            // 
            // DelCategory
            // 
            this.DelCategory.Location = new System.Drawing.Point(325, 96);
            this.DelCategory.Name = "DelCategory";
            this.DelCategory.Size = new System.Drawing.Size(94, 29);
            this.DelCategory.TabIndex = 2;
            this.DelCategory.Text = "Удалить";
            this.DelCategory.UseVisualStyleBackColor = true;
            this.DelCategory.Click += new System.EventHandler(this.DelCategory_Click);
            // 
            // InputWord
            // 
            this.InputWord.Location = new System.Drawing.Point(14, 177);
            this.InputWord.Name = "InputWord";
            this.InputWord.Size = new System.Drawing.Size(176, 27);
            this.InputWord.TabIndex = 0;
            // 
            // comboBoxCategory2
            // 
            this.comboBoxCategory2.FormattingEnabled = true;
            this.comboBoxCategory2.Location = new System.Drawing.Point(194, 178);
            this.comboBoxCategory2.Name = "comboBoxCategory2";
            this.comboBoxCategory2.Size = new System.Drawing.Size(125, 28);
            this.comboBoxCategory2.TabIndex = 1;
            // 
            // AddWord
            // 
            this.AddWord.Location = new System.Drawing.Point(327, 177);
            this.AddWord.Name = "AddWord";
            this.AddWord.Size = new System.Drawing.Size(94, 29);
            this.AddWord.TabIndex = 2;
            this.AddWord.Text = "Добавить";
            this.AddWord.UseVisualStyleBackColor = true;
            this.AddWord.Click += new System.EventHandler(this.AddWord_Click);
            // 
            // comboBoxCategory3
            // 
            this.comboBoxCategory3.FormattingEnabled = true;
            this.comboBoxCategory3.Location = new System.Drawing.Point(14, 212);
            this.comboBoxCategory3.Name = "comboBoxCategory3";
            this.comboBoxCategory3.Size = new System.Drawing.Size(125, 28);
            this.comboBoxCategory3.TabIndex = 1;
            this.comboBoxCategory3.SelectedIndexChanged += new System.EventHandler(this.comboBoxCategory3_SelectedIndexChanged);
            // 
            // comboBoxWord
            // 
            this.comboBoxWord.FormattingEnabled = true;
            this.comboBoxWord.Location = new System.Drawing.Point(145, 213);
            this.comboBoxWord.Name = "comboBoxWord";
            this.comboBoxWord.Size = new System.Drawing.Size(176, 28);
            this.comboBoxWord.TabIndex = 1;
            // 
            // DelWord
            // 
            this.DelWord.Location = new System.Drawing.Point(327, 212);
            this.DelWord.Name = "DelWord";
            this.DelWord.Size = new System.Drawing.Size(94, 29);
            this.DelWord.TabIndex = 2;
            this.DelWord.Text = "Удалить";
            this.DelWord.UseVisualStyleBackColor = true;
            this.DelWord.Click += new System.EventHandler(this.DelWord_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(191, 20);
            this.label1.TabIndex = 3;
            this.label1.Text = "Редактор категорий слова";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 143);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(108, 20);
            this.label2.TabIndex = 3;
            this.label2.Text = "Редактор слов";
            // 
            // WordsListEditor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(432, 253);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.DelWord);
            this.Controls.Add(this.comboBoxWord);
            this.Controls.Add(this.comboBoxCategory3);
            this.Controls.Add(this.AddWord);
            this.Controls.Add(this.comboBoxCategory2);
            this.Controls.Add(this.InputWord);
            this.Controls.Add(this.DelCategory);
            this.Controls.Add(this.AddCategory);
            this.Controls.Add(this.comboBoxCategory);
            this.Controls.Add(this.InputCategory);
            this.MaximumSize = new System.Drawing.Size(450, 300);
            this.MinimumSize = new System.Drawing.Size(450, 300);
            this.Name = "WordsListEditor";
            this.Text = "Редактор словаря";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox InputCategory;
        private System.Windows.Forms.ComboBox comboBoxCategory;
        private System.Windows.Forms.Button AddCategory;
        private System.Windows.Forms.Button DelCategory;
        private System.Windows.Forms.TextBox InputWord;
        private System.Windows.Forms.ComboBox comboBoxCategory2;
        private System.Windows.Forms.Button AddWord;
        private System.Windows.Forms.ComboBox comboBoxCategory3;
        private System.Windows.Forms.ComboBox comboBoxWord;
        private System.Windows.Forms.Button DelWord;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}