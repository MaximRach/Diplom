﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace vkr
{
    public partial class WordsListEditor : Form
    {
        Settings.DbSettings dbsettings = new Settings.DbSettings();
        public WordsListEditor()
        {
            InitializeComponent();
            FillCBCategory();
        }
        public DataTable DictionaryTable()
        {
            string connString = dbsettings.GetConnString();
            NpgsqlConnection nc = new NpgsqlConnection(connString);
            nc.Open();
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = nc;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "SELECT \"Dictionary\".\"word\", \"Category\".\"name\" FROM \"Dictionary\" JOIN \"Category\" ON \"Dictionary\".\"categoryId\" = \"Category\".\"categoryId\";";
            NpgsqlDataReader dr = comm.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            comm.Dispose();
            nc.Close();
            return dt;
        }
        private void FillCBCategory()
        {
            comboBoxCategory.Items.Clear();
            comboBoxCategory2.Items.Clear();
            comboBoxCategory3.Items.Clear();
            string connString = dbsettings.GetConnString();
            NpgsqlConnection nc = new NpgsqlConnection(connString);
            nc.Open();
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = nc;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "SELECT \"name\" FROM \"Category\" ;";
            NpgsqlDataReader dr = comm.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                comboBoxCategory.Items.Add(dt.Rows[i]["name"]);
                comboBoxCategory2.Items.Add(dt.Rows[i]["name"]);
                comboBoxCategory3.Items.Add(dt.Rows[i]["name"]);
            }
            comm.Dispose();
            nc.Close();
        }

        private void AddCategory_Click(object sender, EventArgs e)
        {
            string connString = dbsettings.GetConnString();
            NpgsqlConnection nc = new NpgsqlConnection(connString);
            nc.Open();
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = nc;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "INSERT INTO \"Category\" (\"name\") values ('"+InputCategory.Text+"');";
            comm.ExecuteNonQuery();
            comm.Dispose();
            nc.Close();
            FillCBCategory();
        }

        private void DelCategory_Click(object sender, EventArgs e)
        {
            string connString = dbsettings.GetConnString();
            NpgsqlConnection nc = new NpgsqlConnection(connString);
            nc.Open();
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = nc;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "DELETE FROM \"Category\" WHERE name='"+comboBoxCategory.Text+"';";
            comm.ExecuteNonQuery();
            comm.Dispose();
            nc.Close();
            FillCBCategory();
        }

        private int GetCategoryIdByName(string name)
        {
            string connString = dbsettings.GetConnString();
            NpgsqlConnection nc = new NpgsqlConnection(connString);
            nc.Open();
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = nc;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "SELECT * FROM \"Category\" ;";
            NpgsqlDataReader dr = comm.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if(name== dt.Rows[i]["name"].ToString())
                {
                    comm.Dispose();
                    nc.Close();
                    return Convert.ToInt32(dt.Rows[i]["categoryId"]);
                }
            }
            comm.Dispose();
            nc.Close();
            return 0;
        }

        private void AddWord_Click(object sender, EventArgs e)
        {
            //MessageBox.Show(GetCategoryIdByName(comboBoxCategory2.Text).ToString());
            string connString = dbsettings.GetConnString();
            NpgsqlConnection nc = new NpgsqlConnection(connString);
            nc.Open();
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = nc;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "INSERT INTO \"Dictionary\" (\"categoryId\",\"word\") values ("+ GetCategoryIdByName(comboBoxCategory2.Text).ToString() +
                ",'"+InputWord.Text+"');";
            comm.ExecuteNonQuery();
            comm.Dispose();
            nc.Close();
        }
        private void FillCBWord(int categoryid)
        {
            comboBoxWord.Items.Clear();
            string connString = dbsettings.GetConnString();
            NpgsqlConnection nc = new NpgsqlConnection(connString);
            nc.Open();
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = nc;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "SELECT \"word\" FROM \"Dictionary\" WHERE \"categoryId\"="+ categoryid+" ;";
            NpgsqlDataReader dr = comm.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                comboBoxWord.Items.Add(dt.Rows[i]["word"]);
            }
            comm.Dispose();
            nc.Close();
        }
        private void comboBoxCategory3_SelectedIndexChanged(object sender, EventArgs e)
        {
            FillCBWord(GetCategoryIdByName(comboBoxCategory3.Text));
        }

        private void DelWord_Click(object sender, EventArgs e)
        {
            string connString = dbsettings.GetConnString();
            NpgsqlConnection nc = new NpgsqlConnection(connString);
            nc.Open();
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = nc;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "DELETE FROM \"Dictionary\" WHERE \"categoryId\"=" +GetCategoryIdByName(comboBoxCategory3.Text)+
                " and \"word\"='"+ comboBoxWord.Text + "';";
            comm.ExecuteNonQuery();
            comm.Dispose();
            nc.Close();
            FillCBWord(GetCategoryIdByName(comboBoxCategory3.Text)); 
        }
    }
}
