﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace vkr
{
    public partial class SelfScoreTeam : Form
    {
        Settings.DbSettings dbsettings = new Settings.DbSettings();
        public SelfScoreTeam()
        {
            InitializeComponent();
            FillCBTeam();
        }
        private void FillCBTeam()
        {
            string connString = dbsettings.GetConnString();
            NpgsqlConnection nc = new NpgsqlConnection(connString);
            nc.Open();
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = nc;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "SELECT \"name\" FROM \"Team\" ;";
            NpgsqlDataReader dr = comm.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                comboBoxSSTTeam.Items.Add(dt.Rows[i]["name"]);
            }
            comm.Dispose();
            nc.Close();
        }

        private void FillCBStage()
        {
            comboBoxSSTStage.Items.Clear();
            string connString = dbsettings.GetConnString();
            NpgsqlConnection nc = new NpgsqlConnection(connString);
            nc.Open();
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = nc;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "SELECT \"Stage\".\"name\" FROM \"ScoreTeammate\",  \"Team\",\"Stage\" WHERE \"ScoreTeammate\".\"teamId\" = \"Team\".\"teamId\"" +
                " and \"ScoreTeammate\".\"stageId\" = \"Stage\".\"stageId\" and \"Team\".\"name\"='" + comboBoxSSTTeam.Text + "'; ";
            NpgsqlDataReader dr = comm.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (!comboBoxSSTStage.Items.Contains(dt.Rows[i]["name"]))
                {
                    comboBoxSSTStage.Items.Add(dt.Rows[i]["name"]);
                }
            }
            comm.Dispose();
            nc.Close();
        }
        private void comboBoxSSTTeam_SelectedIndexChanged(object sender, EventArgs e)
        {
            FillCBStage();
        }
        private DataTable GetDataTableForSelfScore()
        {
            string connString = dbsettings.GetConnString();
            NpgsqlConnection nc = new NpgsqlConnection(connString);
            nc.Open();
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = nc;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "SELECT \"ScoreTeammate\".\"scoreTeammate\", \"ScoreTeammate\".\"studAssessingId\",\"ScoreTeammate\".\"studAnalyzedId\"," +
                " \"Stage\".\"name\" FROM \"ScoreTeammate\",  \"Team\",\"Stage\" WHERE \"ScoreTeammate\".\"teamId\" = \"Team\".\"teamId\"" +
                " and \"ScoreTeammate\".\"stageId\" = \"Stage\".\"stageId\" and \"Team\".\"name\"='"+comboBoxSSTTeam.Text+ "' " +
                "and \"Stage\".\"name\"='" + comboBoxSSTStage.Text + "'; ";
            NpgsqlDataReader dr = comm.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            comm.Dispose();
            nc.Close();
            return dt;
        }

        private void comboBoxSSTStage_SelectedIndexChanged(object sender, EventArgs e)
        {
            //dataGridViewSSTSS.DataSource = GetDataTableForSelfScore();
            StudentsSelfScore temp = new StudentsSelfScore();
            temp.GetData(GetDataTableForSelfScore());
            dataGridViewSSTMeanScore.DataSource= temp.TableMean(GetDataTableForSelfScore());
            dataGridViewSSTSS.DataSource = temp.SelfScoreTable(GetDataTableForSelfScore());
        }
    }
}
