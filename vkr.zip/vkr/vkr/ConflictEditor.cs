﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace vkr
{
    public partial class ConflictEditor : Form
    {
        Settings.DbSettings dbsettings = new Settings.DbSettings();
        public ConflictEditor()
        {
            InitializeComponent();
            FillCBTypeConflict();
            FillCBTeam();
            FillCBBroke();
        }
        private void FillCBTypeConflict()
        {
            comboBoxCETypeConflict.Items.Clear();
            comboBoxCETypeConflict2.Items.Clear();
            string connString = dbsettings.GetConnString();
            NpgsqlConnection nc = new NpgsqlConnection(connString);
            nc.Open();
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = nc;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "SELECT \"name\" FROM \"TypeConflict\" ;";
            NpgsqlDataReader dr = comm.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                comboBoxCETypeConflict.Items.Add(dt.Rows[i]["name"]);
                comboBoxCETypeConflict2.Items.Add(dt.Rows[i]["name"]);
            }
            comm.Dispose();
            nc.Close();
        }
        private void FillCBStage()
        {
            comboBoxCEStage.Items.Clear();
            string connString = dbsettings.GetConnString();
            NpgsqlConnection nc = new NpgsqlConnection(connString);
            nc.Open();
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = nc;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "SELECT \"Stage\".\"name\" FROM   \"Team\",\"Stage\" " +
                "WHERE \"Stage\".\"projectId\" = \"Team\".\"projectId\" and \"Team\".\"name\" = '"+comboBoxCETeam.Text+"'; ";
            NpgsqlDataReader dr = comm.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                comboBoxCEStage.Items.Add(dt.Rows[i]["name"]);
            }
            comm.Dispose();
            nc.Close();
        }
        private void FillCBTeam()
        {
            string connString = dbsettings.GetConnString();
            NpgsqlConnection nc = new NpgsqlConnection(connString);
            nc.Open();
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = nc;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "SELECT \"name\" FROM \"Team\" ;";
            NpgsqlDataReader dr = comm.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                comboBoxCETeam.Items.Add(dt.Rows[i]["name"]);
                comboBoxCETeam2.Items.Add(dt.Rows[i]["name"]);
            }
            comm.Dispose();
            nc.Close();
        }
        private void FillCBBroke()
        {
            comboBoxCEBroke.Items.Add("Да");
            comboBoxCEBroke.Items.Add("Нет");
        }
        private void buttonCEAddTypeConflict_Click(object sender, EventArgs e)
        {
            string connString = dbsettings.GetConnString();
            NpgsqlConnection nc = new NpgsqlConnection(connString);
            nc.Open();
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = nc;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "INSERT INTO \"TypeConflict\" (\"name\") values ('" + inputTypeConflict.Text + "');";
            comm.ExecuteNonQuery();
            comm.Dispose();
            nc.Close();
            FillCBTypeConflict();
        }

        private void buttonCEDeleteTypeConflict_Click(object sender, EventArgs e)
        {
            string connString = dbsettings.GetConnString();
            NpgsqlConnection nc = new NpgsqlConnection(connString);
            nc.Open();
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = nc;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "DELETE FROM \"TypeConflict\" WHERE name='" + inputTypeConflict.Text + "';";
            comm.ExecuteNonQuery();
            comm.Dispose();
            nc.Close();
            FillCBTypeConflict();
        }

        private void comboBoxCETeam2_SelectedIndexChanged(object sender, EventArgs e)
        {
            string connString = dbsettings.GetConnString();
            NpgsqlConnection nc = new NpgsqlConnection(connString);
            nc.Open();
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = nc;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "SELECT \"comment\" FROM \"Team\" WHERE name='" + comboBoxCETeam2.Text + "';";
            NpgsqlDataReader dr = comm.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            if (dt.Rows.Count > 0) {
                richTextBoxCEComment.Text = dt.Rows[0]["comment"].ToString();
            }
            comm.Dispose();
            nc.Close();
        }

        private void buttonCEEditComment_Click(object sender, EventArgs e)
        {
            string connString = dbsettings.GetConnString();
            NpgsqlConnection nc = new NpgsqlConnection(connString);
            nc.Open();
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = nc;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "UPDATE \"Team\" SET comment = '"+richTextBoxCEComment.Text+"' WHERE name = '"+comboBoxCETeam2.Text+"';";
            comm.ExecuteNonQuery();
            comm.Dispose();
            nc.Close();
        }

        private void comboBoxCETeam_SelectedIndexChanged(object sender, EventArgs e)
        {
            FillCBStage();
        }
        private int GetTeamIdByName(string name)
        {
            string connString = dbsettings.GetConnString();
            NpgsqlConnection nc = new NpgsqlConnection(connString);
            nc.Open();
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = nc;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "SELECT \"teamId\" FROM \"Team\" WHERE name='"+name+"';";
            NpgsqlDataReader dr = comm.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            comm.Dispose();
            nc.Close();
            return Convert.ToInt32( dt.Rows[0]["teamId"]);
        }
        private int GetTypeConflictIdByName(string name)
        {
            string connString = dbsettings.GetConnString();
            NpgsqlConnection nc = new NpgsqlConnection(connString);
            nc.Open();
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = nc;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "SELECT \"typeConflictId\" FROM \"TypeConflict\" WHERE name='" + name + "';";
            NpgsqlDataReader dr = comm.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            comm.Dispose();
            nc.Close();
            return Convert.ToInt32(dt.Rows[0]["typeConflictId"]);
        }
        private int GetStageIdByName(string name)
        {
            string connString = dbsettings.GetConnString();
            NpgsqlConnection nc = new NpgsqlConnection(connString);
            nc.Open();
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = nc;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "SELECT \"stageId\" FROM \"Stage\" WHERE name='" + name + "';";
            NpgsqlDataReader dr = comm.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            comm.Dispose();
            nc.Close();
            return Convert.ToInt32(dt.Rows[0]["stageId"]);
        }
        private bool GetBrokeByName(string name)
        {
            if (name == "Да")
            {
                return true;
            }
            else { return false; }
        }

        private void buttonCEAddConflict_Click(object sender, EventArgs e)
        {
            string connString = dbsettings.GetConnString();
            NpgsqlConnection nc = new NpgsqlConnection(connString);
            nc.Open();
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = nc;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "INSERT INTO \"Conflict\" (\"teamId\",\"typeConflictId\",\"broke\",\"stageId\") " +
                "values (" + GetTeamIdByName(comboBoxCETeam.Text) + ","+GetTypeConflictIdByName(comboBoxCETypeConflict2.Text)+"," +
                ""+GetBrokeByName(comboBoxCEBroke.Text)+","+GetStageIdByName(comboBoxCEStage.Text)+");";
            comm.ExecuteNonQuery();
            comm.Dispose();
            nc.Close();
            FillCBTypeConflict();
        }
    }
}
