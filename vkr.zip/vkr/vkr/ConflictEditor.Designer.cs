﻿namespace vkr
{
    partial class ConflictEditor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.comboBoxCETypeConflict = new System.Windows.Forms.ComboBox();
            this.inputTypeConflict = new System.Windows.Forms.TextBox();
            this.buttonCEAddTypeConflict = new System.Windows.Forms.Button();
            this.buttonCEDeleteTypeConflict = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBoxCETeam = new System.Windows.Forms.ComboBox();
            this.comboBoxCETypeConflict2 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.comboBoxCEStage = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.comboBoxCEBroke = new System.Windows.Forms.ComboBox();
            this.buttonCEAddConflict = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.comboBoxCETeam2 = new System.Windows.Forms.ComboBox();
            this.buttonCEEditComment = new System.Windows.Forms.Button();
            this.richTextBoxCEComment = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(164, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Причины конфликтов:";
            // 
            // comboBoxCETypeConflict
            // 
            this.comboBoxCETypeConflict.FormattingEnabled = true;
            this.comboBoxCETypeConflict.Location = new System.Drawing.Point(12, 70);
            this.comboBoxCETypeConflict.Name = "comboBoxCETypeConflict";
            this.comboBoxCETypeConflict.Size = new System.Drawing.Size(187, 28);
            this.comboBoxCETypeConflict.TabIndex = 1;
            // 
            // inputTypeConflict
            // 
            this.inputTypeConflict.Location = new System.Drawing.Point(13, 37);
            this.inputTypeConflict.Name = "inputTypeConflict";
            this.inputTypeConflict.Size = new System.Drawing.Size(186, 27);
            this.inputTypeConflict.TabIndex = 2;
            // 
            // buttonCEAddTypeConflict
            // 
            this.buttonCEAddTypeConflict.Location = new System.Drawing.Point(205, 37);
            this.buttonCEAddTypeConflict.Name = "buttonCEAddTypeConflict";
            this.buttonCEAddTypeConflict.Size = new System.Drawing.Size(94, 29);
            this.buttonCEAddTypeConflict.TabIndex = 3;
            this.buttonCEAddTypeConflict.Text = "Добавить";
            this.buttonCEAddTypeConflict.UseVisualStyleBackColor = true;
            this.buttonCEAddTypeConflict.Click += new System.EventHandler(this.buttonCEAddTypeConflict_Click);
            // 
            // buttonCEDeleteTypeConflict
            // 
            this.buttonCEDeleteTypeConflict.Location = new System.Drawing.Point(205, 68);
            this.buttonCEDeleteTypeConflict.Name = "buttonCEDeleteTypeConflict";
            this.buttonCEDeleteTypeConflict.Size = new System.Drawing.Size(94, 29);
            this.buttonCEDeleteTypeConflict.TabIndex = 4;
            this.buttonCEDeleteTypeConflict.Text = "Удалить";
            this.buttonCEDeleteTypeConflict.UseVisualStyleBackColor = true;
            this.buttonCEDeleteTypeConflict.Click += new System.EventHandler(this.buttonCEDeleteTypeConflict_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 105);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 20);
            this.label2.TabIndex = 5;
            this.label2.Text = "Конфликты:";
            // 
            // comboBoxCETeam
            // 
            this.comboBoxCETeam.FormattingEnabled = true;
            this.comboBoxCETeam.Location = new System.Drawing.Point(109, 128);
            this.comboBoxCETeam.Name = "comboBoxCETeam";
            this.comboBoxCETeam.Size = new System.Drawing.Size(190, 28);
            this.comboBoxCETeam.TabIndex = 6;
            this.comboBoxCETeam.SelectedIndexChanged += new System.EventHandler(this.comboBoxCETeam_SelectedIndexChanged);
            // 
            // comboBoxCETypeConflict2
            // 
            this.comboBoxCETypeConflict2.FormattingEnabled = true;
            this.comboBoxCETypeConflict2.Location = new System.Drawing.Point(109, 163);
            this.comboBoxCETypeConflict2.Name = "comboBoxCETypeConflict2";
            this.comboBoxCETypeConflict2.Size = new System.Drawing.Size(190, 28);
            this.comboBoxCETypeConflict2.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 128);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 20);
            this.label3.TabIndex = 8;
            this.label3.Text = "Команда:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 163);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(75, 20);
            this.label4.TabIndex = 9;
            this.label4.Text = "Причина:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(13, 198);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 20);
            this.label5.TabIndex = 10;
            this.label5.Text = "Этап:";
            // 
            // comboBoxCEStage
            // 
            this.comboBoxCEStage.FormattingEnabled = true;
            this.comboBoxCEStage.Location = new System.Drawing.Point(109, 198);
            this.comboBoxCEStage.Name = "comboBoxCEStage";
            this.comboBoxCEStage.Size = new System.Drawing.Size(190, 28);
            this.comboBoxCEStage.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(13, 233);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(60, 20);
            this.label6.TabIndex = 12;
            this.label6.Text = "Распад:";
            // 
            // comboBoxCEBroke
            // 
            this.comboBoxCEBroke.FormattingEnabled = true;
            this.comboBoxCEBroke.Location = new System.Drawing.Point(109, 233);
            this.comboBoxCEBroke.Name = "comboBoxCEBroke";
            this.comboBoxCEBroke.Size = new System.Drawing.Size(190, 28);
            this.comboBoxCEBroke.TabIndex = 13;
            // 
            // buttonCEAddConflict
            // 
            this.buttonCEAddConflict.Location = new System.Drawing.Point(12, 268);
            this.buttonCEAddConflict.Name = "buttonCEAddConflict";
            this.buttonCEAddConflict.Size = new System.Drawing.Size(287, 29);
            this.buttonCEAddConflict.TabIndex = 14;
            this.buttonCEAddConflict.Text = "Добавить";
            this.buttonCEAddConflict.UseVisualStyleBackColor = true;
            this.buttonCEAddConflict.Click += new System.EventHandler(this.buttonCEAddConflict_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(426, 13);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(110, 20);
            this.label7.TabIndex = 15;
            this.label7.Text = "Комментарии:";
            // 
            // comboBoxCETeam2
            // 
            this.comboBoxCETeam2.FormattingEnabled = true;
            this.comboBoxCETeam2.Location = new System.Drawing.Point(426, 38);
            this.comboBoxCETeam2.Name = "comboBoxCETeam2";
            this.comboBoxCETeam2.Size = new System.Drawing.Size(151, 28);
            this.comboBoxCETeam2.TabIndex = 16;
            this.comboBoxCETeam2.SelectedIndexChanged += new System.EventHandler(this.comboBoxCETeam2_SelectedIndexChanged);
            // 
            // buttonCEEditComment
            // 
            this.buttonCEEditComment.Location = new System.Drawing.Point(584, 37);
            this.buttonCEEditComment.Name = "buttonCEEditComment";
            this.buttonCEEditComment.Size = new System.Drawing.Size(204, 29);
            this.buttonCEEditComment.TabIndex = 17;
            this.buttonCEEditComment.Text = "Изменить";
            this.buttonCEEditComment.UseVisualStyleBackColor = true;
            this.buttonCEEditComment.Click += new System.EventHandler(this.buttonCEEditComment_Click);
            // 
            // richTextBoxCEComment
            // 
            this.richTextBoxCEComment.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.richTextBoxCEComment.Location = new System.Drawing.Point(426, 72);
            this.richTextBoxCEComment.Name = "richTextBoxCEComment";
            this.richTextBoxCEComment.Size = new System.Drawing.Size(362, 236);
            this.richTextBoxCEComment.TabIndex = 18;
            this.richTextBoxCEComment.Text = "";
            // 
            // ConflictEditor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 310);
            this.Controls.Add(this.richTextBoxCEComment);
            this.Controls.Add(this.buttonCEEditComment);
            this.Controls.Add(this.comboBoxCETeam2);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.buttonCEAddConflict);
            this.Controls.Add(this.comboBoxCEBroke);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.comboBoxCEStage);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.comboBoxCETypeConflict2);
            this.Controls.Add(this.comboBoxCETeam);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.buttonCEDeleteTypeConflict);
            this.Controls.Add(this.buttonCEAddTypeConflict);
            this.Controls.Add(this.inputTypeConflict);
            this.Controls.Add(this.comboBoxCETypeConflict);
            this.Controls.Add(this.label1);
            this.Name = "ConflictEditor";
            this.Text = "Редактор конфликтов";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBoxCETypeConflict;
        private System.Windows.Forms.TextBox inputTypeConflict;
        private System.Windows.Forms.Button buttonCEAddTypeConflict;
        private System.Windows.Forms.Button buttonCEDeleteTypeConflict;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBoxCETeam;
        private System.Windows.Forms.ComboBox comboBoxCETypeConflict2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox comboBoxCEStage;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox comboBoxCEBroke;
        private System.Windows.Forms.Button buttonCEAddConflict;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox comboBoxCETeam2;
        private System.Windows.Forms.Button buttonCEEditComment;
        private System.Windows.Forms.RichTextBox richTextBoxCEComment;
    }
}