﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ZedGraph;

namespace vkr
{
    public partial class TextSurveyAnalysis : Form
    {
        Settings.DbSettings dbsettings = new Settings.DbSettings();

        public TextSurveyAnalysis()
        {
            InitializeComponent();
            FillCBGroup();
            FillCBSurvey();
            FillCheckedListBoxTSADictionary();
        }
        private void FillCBGroup()
        {
            string connString = dbsettings.GetConnString();
            NpgsqlConnection nc = new NpgsqlConnection(connString);
            nc.Open();
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = nc;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "SELECT \"name\" FROM \"Group\" ;";
            NpgsqlDataReader dr = comm.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                comboBoxGroup.Items.Add(dt.Rows[i]["name"]);
            }
            comm.Dispose();
            nc.Close();
        }
        private void FillCBSurvey()
        {
            string connString = dbsettings.GetConnString();
            NpgsqlConnection nc = new NpgsqlConnection(connString);
            nc.Open();
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = nc;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "SELECT \"name\" FROM \"Survey\" ;";
            NpgsqlDataReader dr = comm.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                comboBoxSurvey.Items.Add(dt.Rows[i]["name"]);
            }
            comm.Dispose();
            nc.Close();
        }

        private void FillCheckedListBoxTSADictionary()
        {
            checkedListBoxTSADictionary.Items.Clear();
            WordsListEditor temp = new WordsListEditor();
            DataTable dt = temp.DictionaryTable();
            for (int i=0; i < dt.Rows.Count; i++)
            {
                checkedListBoxTSADictionary.Items.Add(dt.Rows[i][0]);
            }
        }
        private void TSABTable_Click(object sender, EventArgs e)
        {
            //DataTable dt = TSATable();
            //dataGridViewTSA.DataSource = dt;
            //WordsCounter SelectedWordsCounter = ListWordsToFind();
            //DataTable t = new DataTable();
            //t=temp.ToDataTable();
            //dataGridViewTSA.DataSource=t;
            //AnswerString();
            //SelectedWordsCounter.FindAndCount(AnswerString());
            //dataGridViewTSA.DataSource = SelectedWordsCounter.ToDataTable();
            dataGridViewTSA.DataSource = WordsCounterRezult();
        }
        private DataTable WordsCounterRezult()
        {
            WordsCounter SelectedWordsCounter = ListWordsToFind();
            SelectedWordsCounter.FindAndCount(AnswerString());
            return SelectedWordsCounter.ToDataTable(TSATable().Rows.Count);
        }
        private WordsCounter ListWordsToFind()
        {
            WordsListEditor temp = new WordsListEditor();
            DataTable dt = temp.DictionaryTable();
            WordsCounter rezult = new WordsCounter();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                //checkedListBoxTSADictionary.Items.Add(dt.Rows[i][0]);
                if (checkedListBoxTSADictionary.CheckedItems.Contains(dt.Rows[i][0])){
                    WordCounter word = new WordCounter();
                    word.EditWord(dt.Rows[i][1].ToString(), dt.Rows[i][0].ToString());
                    rezult.AddWord(word);
                }
            }
            return rezult;
        }
        private string AnswerString()
        {
            string rezult = "";
            DataTable dt = TSATable();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                rezult += dt.Rows[i][0];
                rezult += ";";
            }
            return rezult.ToLower();
        }
        private DataTable TSATable()
        {
            string connString = dbsettings.GetConnString();
            NpgsqlConnection nc = new NpgsqlConnection(connString);
            nc.Open();
            NpgsqlCommand comm = new NpgsqlCommand();
            comm.Connection = nc;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "SELECT \"SurveyAnswer1\".\"answerText\", \"SurveyQuestion1\".\"questionText\",\"Student\".\"fistName\"," +
                "\"Student\".\"lastName\" FROM \"TeamStudent\", \"Student\", \"Group\",\"SurveyAnswer1\" ,\"SurveyQuestion1\",\"Survey\" WHERE" +
                " \"SurveyAnswer1\".\"teamStudentId\" = \"TeamStudent\".\"teamStudentId\" and \"TeamStudent\".\"studentId\" = \"Student\".\"studentId\"" +
                " and \"Student\".\"groupId\" = \"Group\".\"groupId\" and \"SurveyAnswer1\".\"surveyQuestion1Id\" = \"SurveyQuestion1\".\"surveyQuestion1Id\"" +
                " and \"SurveyQuestion1\".\"surveyId\" = \"Survey\".\"surveyId\"" +
                " and \"Group\".\"name\" = '" + comboBoxGroup.SelectedItem + "' and \"Survey\".\"name\" = '" + comboBoxSurvey.SelectedItem + "';";
            NpgsqlDataReader dr = comm.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            comm.Dispose();
            nc.Close();
            return dt;
        }

        private void TASBGist_Click(object sender, EventArgs e)
        {
            DataTable dt = WordsCounterRezult();
            zedGraphControlTSA.GraphPane.CurveList.Clear();

            zedGraphControlTSA.GraphPane.GraphObjList.Clear();
            zedGraphControlTSA.GraphPane.Title.Text = "";
            zedGraphControlTSA.GraphPane.XAxis.Title.Text = "";
            zedGraphControlTSA.GraphPane.YAxis.Title.Text = "";
            zedGraphControlTSA.GraphPane.Y2Axis.Title.Text = "";
            zedGraphControlTSA.GraphPane.XAxis.Type = AxisType.Linear;
            zedGraphControlTSA.GraphPane.XAxis.Scale.TextLabels = null;
            zedGraphControlTSA.RestoreScale(zedGraphControlTSA.GraphPane);

            List<double> numbers = new List<double>();
            List<string> words = new List<string>();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                numbers.Add(Convert.ToDouble(dt.Rows[i][2]));
                words.Add(dt.Rows[i][1].ToString());
            }
            string name="Анкета: " + comboBoxGroup.SelectedItem + " Группа: " + comboBoxSurvey.SelectedItem;
            zedGraphControlTSA.GraphPane.Title.Text = name;
            BarItem graph = zedGraphControlTSA.GraphPane.AddBar(name, null, numbers.ToArray(),Color.Orange);
            zedGraphControlTSA.GraphPane.XAxis.Type = AxisType.Text;
            zedGraphControlTSA.GraphPane.XAxis.Scale.TextLabels = words.ToArray();
            zedGraphControlTSA.GraphPane.AxisChange();
            zedGraphControlTSA.GraphPane.XAxis.Title.Text = "Выбранные слова";
            zedGraphControlTSA.GraphPane.YAxis.Title.Text = "Колличество слов";
            zedGraphControlTSA.Invalidate();
        }

        private void buttonTSASelectNoth_Click(object sender, EventArgs e)
        {
            for (int i=0; i < checkedListBoxTSADictionary.Items.Count; i++)
            {
                checkedListBoxTSADictionary.SetItemChecked(i, false);
            }
        }

        private void buttonTSASelectAll_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < checkedListBoxTSADictionary.Items.Count; i++)
            {
                checkedListBoxTSADictionary.SetItemChecked(i, true);
            }
        }

        private void buttonTSAUpdateDictionary_Click(object sender, EventArgs e)
        {
            FillCheckedListBoxTSADictionary();
        }

        private void buttonTSAPolarGraph_Click(object sender, EventArgs e)
        {
            /*if (checkedListBoxTSADictionary.CheckedItems.Count != 4)
            {
                MessageBox.Show("Выбрано не 4 слова");
            }
            else
            {
                DataTable dt = WordsCounterRezult();
                zedGraphControlTSA.GraphPane.CurveList.Clear();

                zedGraphControlTSA.GraphPane.GraphObjList.Clear();
                zedGraphControlTSA.GraphPane.Title.Text = "";
                zedGraphControlTSA.GraphPane.XAxis.Title.Text = "";
                zedGraphControlTSA.GraphPane.YAxis.Title.Text = "";
                zedGraphControlTSA.GraphPane.Y2Axis.Title.Text = "";
                zedGraphControlTSA.GraphPane.XAxis.Type = AxisType.Linear;
                zedGraphControlTSA.GraphPane.XAxis.Scale.TextLabels = null;
                zedGraphControlTSA.RestoreScale(zedGraphControlTSA.GraphPane);

                zedGraphControlTSA.GraphPane.XAxis.Cross = 0.0;
                zedGraphControlTSA.GraphPane.YAxis.Cross = 0.0;
                string name = "Анкета: " + comboBoxGroup.SelectedItem + " Группа: " + comboBoxSurvey.SelectedItem;
                zedGraphControlTSA.GraphPane.Title.Text = name;
                zedGraphControlTSA.GraphPane.XAxis.MajorGrid.IsVisible = true;
                zedGraphControlTSA.GraphPane.YAxis.MajorGrid.IsVisible = true;
                zedGraphControlTSA.GraphPane.YAxis.MajorGrid.IsZeroLine = false;
                zedGraphControlTSA.GraphPane.XAxis.Title.IsVisible = false;
                zedGraphControlTSA.GraphPane.YAxis.Title.IsVisible = false;
                RadarPointList points = new RadarPointList();
                // Обход точек будет осуществляться против часовой стрелки
                points.Clockwise = false;
                // Первая точка - сверху над началом координат
                points.Add(Convert.ToDouble(dt.Rows[0][2]), 1);
                TextObj text1 = new TextObj(dt.Rows[0][1].ToString(), 0.2, Convert.ToDouble(dt.Rows[0][2]) + 0.2);
                // Вторая точка - слева от начала координат
                points.Add(Convert.ToDouble(dt.Rows[1][2]), 1);
                TextObj text2 = new TextObj(dt.Rows[1][1].ToString(), -Convert.ToDouble(dt.Rows[1][2]) + 0.2, 0.2);
                // Третья точка - снизу под началом координат
                points.Add(Convert.ToDouble(dt.Rows[2][2]), 1);
                TextObj text3 = new TextObj(dt.Rows[2][1].ToString(), 0.2, 0.2 - Convert.ToDouble(dt.Rows[2][2]));
                // Четвертая точка - справа от начала координат
                points.Add(Convert.ToDouble(dt.Rows[3][2]), 1);
                TextObj text4 = new TextObj(dt.Rows[3][1].ToString(), Convert.ToDouble(dt.Rows[3][2]) + 0.2, 0.2);
                zedGraphControlTSA.GraphPane.GraphObjList.Add(text1);
                zedGraphControlTSA.GraphPane.GraphObjList.Add(text2);
                zedGraphControlTSA.GraphPane.GraphObjList.Add(text3);
                zedGraphControlTSA.GraphPane.GraphObjList.Add(text4);
                // Добавляем кривую по этим четырем точкам
                LineItem myCurve = zedGraphControlTSA.GraphPane.AddCurve("", points, Color.Orange, SymbolType.None);
                zedGraphControlTSA.AxisChange();
                zedGraphControlTSA.Invalidate();
            }*/


            DataTable dt = WordsCounterRezult();
            zedGraphControlTSA.GraphPane.CurveList.Clear();

            zedGraphControlTSA.GraphPane.GraphObjList.Clear();
            zedGraphControlTSA.GraphPane.Title.Text = "";
            zedGraphControlTSA.GraphPane.XAxis.Title.Text = "";
            zedGraphControlTSA.GraphPane.YAxis.Title.Text = "";
            zedGraphControlTSA.GraphPane.Y2Axis.Title.Text = "";
            zedGraphControlTSA.GraphPane.XAxis.Type = AxisType.Linear;
            zedGraphControlTSA.GraphPane.XAxis.Scale.TextLabels = null;
            zedGraphControlTSA.RestoreScale(zedGraphControlTSA.GraphPane);

            zedGraphControlTSA.GraphPane.XAxis.Cross = 0.0;
            zedGraphControlTSA.GraphPane.YAxis.Cross = 0.0;
            string name = "Анкета: " + comboBoxGroup.SelectedItem + " Группа: " + comboBoxSurvey.SelectedItem;
            zedGraphControlTSA.GraphPane.Title.Text = name;
            zedGraphControlTSA.GraphPane.XAxis.MajorGrid.IsVisible = true;
            zedGraphControlTSA.GraphPane.YAxis.MajorGrid.IsVisible = true;
            zedGraphControlTSA.GraphPane.YAxis.MajorGrid.IsZeroLine = false;
            zedGraphControlTSA.GraphPane.XAxis.Title.IsVisible = false;
            zedGraphControlTSA.GraphPane.YAxis.Title.IsVisible = false;
            //угол между прямыми
            double f;
            if (dt.Rows.Count != 0)
            {
                 f = 360 / dt.Rows.Count;
            }
            else
            {
                 f = 360;
            }
            //dataGridViewTSA.DataSource = dt;
            List<double> listX = new List<double>();
            List<double> listY = new List<double>();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                double x = decX(0 + i * f,Convert.ToDouble( dt.Rows[i][2]));
                double y = decY(0 + i * f, Convert.ToDouble(dt.Rows[i][2]));
                PointPairList list = new PointPairList();
                list.Add(0, 0);
                list.Add(x, y);
                if (Convert.ToDouble(dt.Rows[i][2]) != 0)
                {
                    listX.Add(x);
                    listY.Add(y);
                }
                LineItem myCurve = zedGraphControlTSA.GraphPane.AddCurve(/*dt.Rows[i][1].ToString()*/"", list, Color.Red, SymbolType.Diamond);
                myCurve.Line.Width = 3;
                TextObj text = new TextObj(dt.Rows[i][1].ToString(), decX(0 + i * f, Convert.ToDouble(dt.Rows[i][2])),decY(0 + i * f, Convert.ToDouble(dt.Rows[i][2])+0.2));
                zedGraphControlTSA.GraphPane.GraphObjList.Add(text);
            }
            if (listX.Count != 0)
            {
                listX.Add(listX[0]);
                listY.Add(listY[0]);
            }
            LineItem myCurvef = zedGraphControlTSA.GraphPane.AddCurve("", listX.ToArray(), listY.ToArray(), Color.Orange, SymbolType.None);
            zedGraphControlTSA.AxisChange();
            zedGraphControlTSA.Invalidate();
            
        }
        private double decX(double f, double r)
        {
            return r * Math.Cos(f * Math.PI / 180);
        }
        private double decY(double f, double r)
        {
            return r * Math.Sin(f * Math.PI / 180);
        }
        private void buttonTSAStartWLE_Click(object sender, EventArgs e)
        {
            WordsListEditor WLE = new WordsListEditor();
            WLE.Show();
        }
    }
}
