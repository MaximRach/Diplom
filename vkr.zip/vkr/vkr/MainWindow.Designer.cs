﻿namespace vkr
{
    partial class MainWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.MwBTextSurvey = new System.Windows.Forms.Button();
            this.MwBScoreSurvey = new System.Windows.Forms.Button();
            this.MwBScore = new System.Windows.Forms.Button();
            this.MwBBelbinRez = new System.Windows.Forms.Button();
            this.MwBScoreTeammate = new System.Windows.Forms.Button();
            this.MwBConflict = new System.Windows.Forms.Button();
            this.MwBDBSettings = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // MwBTextSurvey
            // 
            this.MwBTextSurvey.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MwBTextSurvey.Location = new System.Drawing.Point(13, 13);
            this.MwBTextSurvey.Name = "MwBTextSurvey";
            this.MwBTextSurvey.Size = new System.Drawing.Size(423, 52);
            this.MwBTextSurvey.TabIndex = 0;
            this.MwBTextSurvey.Text = "Обработка текстовых анкет";
            this.MwBTextSurvey.UseVisualStyleBackColor = true;
            this.MwBTextSurvey.Click += new System.EventHandler(this.MwBTextSurvey_Click);
            // 
            // MwBScoreSurvey
            // 
            this.MwBScoreSurvey.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MwBScoreSurvey.Location = new System.Drawing.Point(13, 71);
            this.MwBScoreSurvey.Name = "MwBScoreSurvey";
            this.MwBScoreSurvey.Size = new System.Drawing.Size(423, 52);
            this.MwBScoreSurvey.TabIndex = 0;
            this.MwBScoreSurvey.Text = "Обработка балльных анкет";
            this.MwBScoreSurvey.UseVisualStyleBackColor = true;
            this.MwBScoreSurvey.Click += new System.EventHandler(this.MwBScoreSurvey_Click);
            // 
            // MwBScore
            // 
            this.MwBScore.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MwBScore.Location = new System.Drawing.Point(13, 129);
            this.MwBScore.Name = "MwBScore";
            this.MwBScore.Size = new System.Drawing.Size(423, 52);
            this.MwBScore.TabIndex = 0;
            this.MwBScore.Text = "Оценки";
            this.MwBScore.UseVisualStyleBackColor = true;
            this.MwBScore.Click += new System.EventHandler(this.MwBScore_Click);
            // 
            // MwBBelbinRez
            // 
            this.MwBBelbinRez.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MwBBelbinRez.Location = new System.Drawing.Point(12, 187);
            this.MwBBelbinRez.Name = "MwBBelbinRez";
            this.MwBBelbinRez.Size = new System.Drawing.Size(423, 52);
            this.MwBBelbinRez.TabIndex = 0;
            this.MwBBelbinRez.Text = "Результаты теста Белбина";
            this.MwBBelbinRez.UseVisualStyleBackColor = true;
            this.MwBBelbinRez.Click += new System.EventHandler(this.MwBBelbinRez_Click);
            // 
            // MwBScoreTeammate
            // 
            this.MwBScoreTeammate.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MwBScoreTeammate.Location = new System.Drawing.Point(12, 245);
            this.MwBScoreTeammate.Name = "MwBScoreTeammate";
            this.MwBScoreTeammate.Size = new System.Drawing.Size(423, 52);
            this.MwBScoreTeammate.TabIndex = 0;
            this.MwBScoreTeammate.Text = "Самооценка команд";
            this.MwBScoreTeammate.UseVisualStyleBackColor = true;
            this.MwBScoreTeammate.Click += new System.EventHandler(this.MwBScoreTeammate_Click);
            // 
            // MwBConflict
            // 
            this.MwBConflict.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MwBConflict.Location = new System.Drawing.Point(12, 303);
            this.MwBConflict.Name = "MwBConflict";
            this.MwBConflict.Size = new System.Drawing.Size(423, 52);
            this.MwBConflict.TabIndex = 0;
            this.MwBConflict.Text = "Конфликты";
            this.MwBConflict.UseVisualStyleBackColor = true;
            this.MwBConflict.Click += new System.EventHandler(this.MwBConflict_Click);
            // 
            // MwBDBSettings
            // 
            this.MwBDBSettings.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MwBDBSettings.Location = new System.Drawing.Point(13, 361);
            this.MwBDBSettings.Name = "MwBDBSettings";
            this.MwBDBSettings.Size = new System.Drawing.Size(423, 52);
            this.MwBDBSettings.TabIndex = 0;
            this.MwBDBSettings.Text = "Настройка подключения к БД";
            this.MwBDBSettings.UseVisualStyleBackColor = true;
            this.MwBDBSettings.Click += new System.EventHandler(this.MwBDBSettings_Click);
            // 
            // MainWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(448, 423);
            this.Controls.Add(this.MwBDBSettings);
            this.Controls.Add(this.MwBConflict);
            this.Controls.Add(this.MwBScoreTeammate);
            this.Controls.Add(this.MwBBelbinRez);
            this.Controls.Add(this.MwBScore);
            this.Controls.Add(this.MwBScoreSurvey);
            this.Controls.Add(this.MwBTextSurvey);
            this.Name = "MainWindow";
            this.Text = "Анализ результатов проектной деятельности";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button MwBTextSurvey;
        private System.Windows.Forms.Button MwBScoreSurvey;
        private System.Windows.Forms.Button MwBScore;
        private System.Windows.Forms.Button MwBBelbinRez;
        private System.Windows.Forms.Button MwBScoreTeammate;
        private System.Windows.Forms.Button MwBConflict;
        private System.Windows.Forms.Button MwBDBSettings;
    }
}