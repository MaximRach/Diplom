﻿using System;
using System.Collections.Generic;
using System.Text;

namespace vkr
{
    public class Globals
    {
        public static string DbSettingsFile = "config/db_config.xml";
    }
}
